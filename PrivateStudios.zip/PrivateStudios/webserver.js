﻿'use strict';
const express = require('express');
const { createServer } = require('node:http');
const { Server } = require('socket.io');


const { io } = require("./gameserver.js");

const webserver = express();
const server = createServer(webserver);

/*
 * temp web server.
 */
const path = require("path");
//console.log(util.inspect(this.usersInQueue, {depth:1, colors:true}))
//console.log(io.sockets.adapter.rooms);

server.listen(3000, () => {
    console.log('server running at http://localhost:3000');
});

io = new Server(server);
webserver.set("socket.io", io); // <== this line

webserver.get(['/:routeType(web|client|server)',
    '/:routeType(web|client|server)/:resourceSubType(js|img|pages)',
    '/:routeType(web|client|server)/:resourceSubType(js|img|pages)/:fileName',
    '/:routeType(web|client|server)/:resourceSubType(js|img|pages)/:resourceSubSubType(ui|furni)/:fileName'
], (req, res) => {

    var requestedUrl = './';

    if (req.params.routeType != undefined) {
        requestedUrl += req.params.routeType;
        //console.log('adding route');
    }

    if (req.params.resourceSubType != undefined) {
        requestedUrl += '/' + req.params.resourceSubType;
        //console.log('adding route sub type');
    }
    if (req.params.resourceSubSubType != undefined) {
        requestedUrl += '/' + req.params.resourceSubSubType;
        //console.log('adding resourceSubSubType');
    }
    if (req.params.fileName != undefined) {
        requestedUrl += '/' + req.params.fileName;
        //console.log('adding filename');
    }


    res.sendFile('' + requestedUrl, { root: __dirname });
    //console.log('user asked for a client file: ' + requestedUrl);
});
