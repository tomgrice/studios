'use strict';
/**
 * @field as Room
 */
var RoomList = {};
var PlayerList = {};
//var io = require("socket.io");

/**
 * Custom data type defining a programming language
 * @typedef {Object} Player
 * @property {number} id - Language id
 * @property {string} name - Language name
 * @property {string} software - Projects it can build
 * @property {number} year - the year it came to life
 */

class ServerVariables {
    constructor() {

    }
}

module.exports = { RoomList: RoomList, PlayerList: PlayerList, ServerVariables: ServerVariables};
