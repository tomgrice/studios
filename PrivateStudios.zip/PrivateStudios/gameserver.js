'use strict';

/* socket.configure(function() {     socket.set("transports", ["websocket"]);     socket.set("log level", 8); }); */
// npm install socket.io
// npm install sqlite3

var util = require("util");

var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./test.db');
db.on("error", function (error) {
	console.log("Getting an error : ", error);
});

var PlayerList = require('./ServerVariables.js').PlayerList;
var RoomList = require('./ServerVariables.js').RoomList;

/*
 * temp web server.
 */
//const path = require("path");
const { createServer } = require('node:http');
const { Server } = require('socket.io');
const express = require('express');
const webserver = express();
const server = createServer(webserver);

var io = new Server(server);
module.exports = { io: io } // exporting io to use in other modules, namely Player and Room.

webserver.set("socket.io", io);    // <== this line

webserver.get(['/:routeType(web|client|server)',
	// API Routes
	// 
	// Client Routes
	'/:routeType(web|client|server|api)/:resourceSubType(js|img|pages|v1)',
	'/:routeType(web|client|server|api)/:resourceSubType(js|img|pages|v1)/:fileName',
	'/:routeType(web|client|server|api)/:resourceSubType(js|img|pages|v1)/:resourceSubSubType(ui|furni|user)/:fileName',
	'/api/v1/users'
], (req, res) => {

	console.log('get request');

	var requestedUrl = './';

	if (req.params.routeType != undefined) {
		requestedUrl += req.params.routeType;
		//console.log('adding route');
	}

	if (req.params.resourceSubType != undefined) {
		requestedUrl += '/' + req.params.resourceSubType;
		//console.log('adding route sub type');
	}
	if (req.params.resourceSubSubType != undefined) {
		requestedUrl += '/' + req.params.resourceSubSubType;
		//console.log('adding resourceSubSubType');
	}
	if (req.params.fileName != undefined) {
		requestedUrl += '/' + req.params.fileName;
		//console.log('adding filename');
	}

	
	if (req.params.routeType == 'server' && req.params.resourceSubType == 'v1' && req.params.resourceSubSubType == 'user' && req.params.fileName == 'createaccount') { //temporary to allow registering accounts
		console.log('yea no');
		console.log(req.params);
		//res.sendStatus(200);
		res.sendFile('./client/pages/createaccount.html', { root: __dirname });
		//res.end();
	} else {
		console.log(requestedUrl)
		res.sendFile('' + requestedUrl, { root: __dirname });
		//res.end();
	}	//console.log('user asked for a client file: ' + requestedUrl);
});

webserver.use('/:routeType(server)/:resourceSubType(v1)/:resourceSubSubType(user)/:fileName(create)', express.json());
webserver.use('/:routeType(server)/:resourceSubType(v1)/:resourceSubSubType(user)/:fileName(create)', express.urlencoded({ extended: true }));

///server/v1/user/create
webserver.post([
	'/:routeType(server)/:resourceSubType(v1)/:resourceSubSubType(user)/:fileName(create)'
], (req, res) => {


	var statement = db.prepare("INSERT INTO players(username, password, status, money, displayname, gender, body, chest, legs, eye, face, hair, head, lefthand, leftsleeve, righthand, rightsleeve, shoes) VALUES($username, $password, $status, $money, $displayname, $gender, $body, $chest, $legs, $eye, $face, $hair, $head, $lefthand, $leftsleeve, $righthand, $rightsleeve, $shoes);");

	var args = {
		$username: req.body.uname,
		$password: req.body.pass,
		$status: 0,
		$money: 1000000,
		$displayname: req.body.dname,
		$gender: req.body.value_body,
		$body: req.body.value_body,
		$chest: req.body.value_chest,
		$legs: req.body.value_legs,
		$eye: req.body.value_eye,
		$face: req.body.value_face,
		$hair: req.body.value_hair,
		$head: req.body.value_head,
		$lefthand: req.body.value_hands,
		$leftsleeve: req.body.value_sleeves,
		$righthand: req.body.value_hands,
		$rightsleeve: req.body.value_sleeves,
		$shoes: req.body.value_shoes
	};


	/*
	CREATE TABLE inventory(
   id INTEGER AUTO_INCREMENT,
   userid INTEGER,
   items text
);
	*/
	statement.run(args, function (err) {
		console.log([util.inspect(this), err]);
		//console.log(this.lastID);

		var inventory_statement = db.prepare("INSERT INTO inventory(id, userid, items) VALUES($id, $userid, $items);");
		var inventory_args = {
			$id: this.lastID,
			$userid: this.lastID,
			$items: '{"0":{"id":3,"amount":20},"2":{"id":3,"amount":20},"3":{"id":3,"amount":20},"4":{"id":3,"amount":1},"5":{"id":3,"amount":1},"6":{"id":3,"amount":1},"7":{"id":3,"amount":1},"8":{"id":3,"amount":1},"9":{"id":3,"amount":20},"10":{"id":3,"amount":1},"11":{"id":3,"amount":1},"12":{"id":1,"amount":1},"13":{"id":1,"amount":1},"14":{"id":1,"amount":1},"15":{"id":1,"amount":1},"16":{"id":1,"amount":100},"17":{"id":1,"amount":1},"18":{"id":1,"amount":100},"19":{"id":1,"amount":1},"20":{"id":1,"amount":1},"21":{"id":1,"amount":1},"22":{"id":1,"amount":100},"23":{"id":1,"amount":100},"24":{"id":1,"amount":100}}'
		}
		inventory_statement.run(inventory_args);
		inventory_statement.finalize();

	});

	statement.finalize();

	res.sendStatus(200);
	res.end();

});

//console.log(util.inspect(this.usersInQueue, {depth:1, colors:true}))
//console.log(io.sockets.adapter.rooms);



const Player = require('./Player.js').class;
/**
 * @typedef {import ('./Player.js').Player} Player
 */

const Room = require('./Room.js').class;
/**
 * @typedef {import ('./Room.js').Room} Room
 */




server.listen(3000, () => {
	console.log('server running at http://localhost:3000');
});









//SERVER CODE
/**
 * @argument {any} client
 * @argument {any} client.player as
 * 
 */
var onSocketConnect = function (client) {
	util.log("[onSocketConnect]" + " New socket connection made (" + client.id + ")");
	util.log('[onSocketConnect] Creating a player instance.');


	client.player = new Player(); // each client gets a player.
	client.player.clientid = client.id;
	PlayerList[client.id] = client.player;

	client.on('debug', function (data) {
		console.log("Client sent debug packet with value: " + data + " player: " + this.player.id);
	});

	client.on('SendChat', function (data) {
		//socket.emit('SendChat', { id: id, name: name, message: message, x: x, y: y } );
		io.sockets.in(this.player.roomid).emit('msgSent', { id: data.id, name: data.name, "msg": data.message, x: data.x, y: data.y });
		console.log("player " + this.player.id + " said: \"" + data.message + "\"");
	});

	util.log('[onSocketConnect] Registering Socket handlers..');
	client.on("disconnect", onClientDisconnect);
	client.on("RoomRequest", roomRequest); ``
	client.on("ActiveRoomRequest", activeRoomRequest);
	client.on("buyItem", onbuyItem);
	client.on("RoomEnter", onRoomEnter);
	client.on("CreateMyStudio", onCreateMyStudio);
	client.on('LoginRequest', performLogin);
	client.on('CreateRoom', createRoom);
	client.on('furniToRoom', addFurniToRoom);
	client.on('deleteFurni', deleteFurniFromRoom);
	client.on('rotateFurni', rotateFurniInRoom);
	client.on('movePlayer', onMovePlayer); // TODO : Check if the user can move there to begin with...?
};

var onSocketDisconnect = function (client) {
	util.log("[onSocketDisconnect]" + " New socket connection made (" + client.id + ")");
	if (this.player != undefined) {
		this.player.leaveRoom();
		console.log('player was not undefined');
	}

	util.log("Player has disconnected: " + client.id);
};

function rotateFurniInRoom(data) {
	console.log(data);
	var client = this;

	RoomList[client.player.roomid].rotateFurni(client.player, data);
}

function onbuyItem(data) {
	console.log("buy item: "); console.log(data);
	client.player.buyItem(client.player, data);
}


function addFurniToRoom(data) {
	util.log(['addFurniToRoom', data]);
	var client = this;
	//console.log("add furni ~~  " + JSON.stringify(data));
	RoomList[client.player.roomid].addFurni(client.player, data);

}

function deleteFurniFromRoom(data) {
	var client = this;
	console.log("remove furni::::: " + JSON.stringify(data));
	RoomList[client.player.roomid].deleteFurni(client.player, data);
}

/**
 * @param {int} col new column coordinate for the user to move to
 * @param {int} row new row coordinate for the user to move to
 */
function onMovePlayer(col, row) {
	var client = this;
	client.player.move(col, row);
}

/**
 * Creates a room for the player.
 * @param {int} roomType the kind of room that is being requested to create.
 */
function createRoom(roomType) {
	util.log(this.id + " wants to create a room type " + roomType);
}



function onCreateMyStudio(studio) {
	var client = this;
	console.log(client.id + " requested to create a new room: ");
	console.log(studio);
	client.player.createRoom(studio);
}


function onRoomEnter(roomid) {
	this.player.joinRoom(roomid);

	var room = RoomList[roomid];

	if (room == undefined) {
		
		room = new Room(roomid);
		
	}
	room.loaded = false; // TODO: bugfix - if furniture is changed, players that join until the database entry is complete, new players won't see changes in the room. In testing it took up to 7-10 seconds. add a flag if room has map changes. if the flag is true, force room to reload and defer room queue. better option is to serialize and await room load for already loaded room.
	room.load();
	room.addUser(this.player);
}

//Send all users in the user's current room a notification to remove the client from their list because they have left the room/game.
function onClientDisconnect() {
	if (this.player == undefined) {
		this.disconnect();
	} else {
		this.player.leaveRoom(); // this would fail otherwise?
	}
	util.log("Player has disconnected: " + this.id);
};

function performLogin(login) {
	var username = login.username;
	var password = login.password;

	this.player.load(username, password);
}

function activeRoomRequest() { /*packet: 7, RoomResponse */
	var data = {};
	var roomids = Object.keys(RoomList);

	for (var roomid = 0; roomid < roomids.length; roomid++) {
		console.log("aabbb" + roomids[roomid]);

		data[roomids[roomid]] = {
			"id": RoomList[roomids[roomid]].id,
			"name": RoomList[roomids[roomid]].name,
			"ownerid": RoomList[roomids[roomid]].ownerid,
			"ownername": RoomList[roomids[roomid]].ownername,
			"type": RoomList[roomids[roomid]].type,
			"location": RoomList[roomids[roomid]].location,
			"description": RoomList[roomids[roomid]].description,
			"playercount": Object.keys(RoomList[roomids[roomid]].users).length

		};
	}

	this.emit("activeRoomResponse", data);
}


function roomRequest() { /*packet: 7, RoomResponse */
	var data = {};

	db.each("SELECT r.id as id, r.playerid as playerid, p.displayname as ownername, r.roomtype as roomtype, r.description as description, r.location as location, r.name as name FROM rooms as r INNER JOIN players p on p.id = r.playerid;", function (err, row) {
		row.playercount = 0;
		data[row.id] = row;
	}, () => {
		this.emit("roomResponse", data);
		console.log(data);
	});
};


util.log("Initializing Server.");
io.sockets.on("connection", onSocketConnect); // globally register the connection handler.
io.sockets.on("connection", onSocketDisconnect); // globally register the connection handler.

process.on('SIGINT', function () {
	console.log('closing database handle.');
	process.exit();
	db.close();
});


/*
//Enable this for Production use.
 process.on('uncaughtException', function (err) {
 console.log('Caught exception: ' + err);
 });
 */

