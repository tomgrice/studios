var util = require("util");
var Item = require('./Item.js');
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./test.db');

var PlayerList = require('./ServerVariables.js').PlayerList;

class Inventory {

	constructor(userid) {
		this.id = null; // this will get replaced once it is loaded.
		this.userid = userid;
		this.maxSlots = 250;
		this.usedSlots = 0;
		this.items = {};
	}
	
	
	load(callback) {
	
		//console.log('inventory load called');
	
		db.serialize(() => {
			db.each("SELECT id, userid, items FROM inventory where userid='"+this.userid+"'",
			(err, row) => {
				if (err) {
					console.log('loading inventory resulted in error: ' + err);
				} 
				this.id = row.id;
				this.userid = row.userid;
				this.items = JSON.parse(row.items);
				util.log('Player.inventory.load(): complete for userid (' + this.userid + ')' + '.');
				this.isLoaded = true;
				//self.user.isLoaded = true;
				callback(); // this triggers the player ready function in player class :)!
			});
			//this section would get called before database results are completed..
		});
		
	}
	
	setupNew() {


		var statement = db.prepare("INSERT INTO inventory(userid, items) VALUES($playerid, $items);");
		
		var args = {
			'$playerid': this.id,// Player.list[this.id].id,
			'$items': '{}'
		};


		console.log(args);
		statement.run(args);
		statement.finalize();
		console.log(statement);
		
	}

	
	getItemSlot(id) {
		for (var invSlot = 0; invSlot < Object.keys(this.items).length; invSlot++) {

			if (this.items[invSlot] == undefined) {
				console.log('slot ' + invSlot + ' is undefined');
				continue;
			}

			if (this.items[invSlot].id == id) {
				util.log("UserID " + this.userid + " has ItemID " + id + " in inventory slot " + invSlot);
				return invSlot;
			}
		}
		
		return false;
	}
	
	saveInventory() {
		util.log('UserID ' + this.userid + ' saving inventory.');
		var invtToSave = JSON.stringify(this.items);

		var statement = db.prepare("UPDATE inventory SET items = $items where userid = $userid;");
		//CREATE TABLE room_furniture(id integer primary key autoincrement, furniowner integer, roomid integer, furniid integer, row integer, col integer, direction integer);

		var args = {
			'$items': JSON.stringify(this.items),// Player.list[this.id].id,
			'$userid': this.userid
		};

		console.log(args);
		statement.run(args);
		statement.finalize();
		console.log(statement);
		//statement.run({ 1: null, 2: player.id, 3: player.room.id, 4: data.itemid, 5: data.row, 6: data.col, 7: data.itemdir });
		//statement.finalize();

	}

	cleanInventory(slot) {
		var isSlotClean = true;

		if (this.items[slot] == undefined) {
			this.items[slot] = {"id": 0, "amount":0}
;
			isSlotClean = false;
		}

		if (!isSlotClean) {
			//patch things.
		}
	}

	hasItem(id, amount) {

		for (var invSlot = 0; invSlot < Object.keys(this.items).length; invSlot++) {

			if (this.items[invSlot] == undefined) {

				console.log('slot ' + invSlot + ' is undefined');
				continue;
			}

			if (this.items[invSlot].id == id && this.items[invSlot].amount >= amount) {
				util.log("[USERID-" + this.userid + "]"
				+ " has " + this.items[invSlot].amount 
				+ " (minimum: " + amount + ")"
				+ " of ItemID " + id + ' in inventory slot ' + invSlot + ".");
				return true;
			} else {
				util.log("[USERID-" + this.userid + "]"
				+ " has " + this.items[invSlot].amount 
				+ " (minimum: " + amount + ")"
				+ " of ItemID " + this.items[invSlot].id  + ' in inventory slot ' + invSlot + ".");
			}
		}
		util.log("[USERID-" + this.userid + "] does not have at least " + amount + " of item ID " + id);
		return false;
	}
	
	getEmptySlot() {

		for(var invSlot = 0; invSlot < this.maxSlots; invSlot++) {

			if (this.items[invSlot] == undefined || this.items[invSlot].id == -1) {
				util.log("Found empty slot: " + invSlot);
				return invSlot;
			}
			
		}
		
		return false;
	}
	
	hasSpace() {
		if (this.usedSlots < this.maxSlots) {
			util.log("[USERID-" + this.userid + "] has " + (this.maxSlots - this.usedSlots) + " inventory space left.");
			return true;
		}
		util.log("[USERID-" + this.userid + "] has no inventory space left!");
		return false;
	}
	
	addItem(id, amount) {
	
		if (this.hasItem(id, 1)) { // Yes
			var itemSlot = this.getItemSlot(id);
			if (itemSlot >= 0) { // add to amount i have. without using up another inventory slot
				this.items[this.getItemSlot()].amount += amount; 
			} else {
				util.log("ERROR ?? While trying to add an item, The user has it in their inventory, but itemslot wasnt found?");
			}
		} else { // I dont have this item in inventory already so take up a new slot and add the item (with amount)
			if (this.hasSpace()) {
				this.usedSlots++;
				var emptySlot = this.getEmptySlot();
				this.items[emptySlot].id = id;
				this.items[emptySlot].amount = amount;
				util.log("Inventory.add Item " + id + " x" + amount + " in inventory slot " + emptySlot + ".");
			}
			
		}
		
		this.saveInventory();
	}
	
	//check if I have the item, check if i have enough of that item  check if i can even remove it ?
	removeItem(id, amount) {  
		//util.log("UserID " + this.userid + " wants to remove " + amount + " of ItemID " + id + " from their Iventory.");
		if (this.hasItem(id, amount)) { // Yes
			var itemSlot = this.getItemSlot(id); // this should never be a no because of the if condition....
			console.log('dbg1');
			console.log(itemSlot);
			console.log(this.items);
			console.log('dbg2');

			this.items[itemSlot].amount = this.items[itemSlot].amount - amount; // add to amount i have. without using up another inventory slot
			
			util.log("[UserID-" + this.userid + "] removed " + amount + " of ItemID " + id + " from their inventory. ");
			if (this.items[itemSlot].amount < 1) {
				util.log("[UserID-" + this.userid + "] No ItemID " + id + " remaining in the slot.");
				this.items[itemSlot].id = 0;
				this.items[itemSlot].amount = 0;
				//delete this.items[itemSlot];
				this.usedSlots = this.usedSlots-1;

			}

			console.log(this.items);

		} else { // I dont have this item in inventory already so take up a new slot and add the item (with amount)
			util.log('[UserID-' + this.userid + '] is trying to remove item in quantity they do not have!');
		}
		
		this.saveInventory();
	}
}

module.exports = Inventory;
