'use strict';
/**
 * Room Module
 * @module Room
 */

var util = require("util");
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./test.db');

var PlayerList = require('./ServerVariables.js').PlayerList;
var RoomList = require('./ServerVariables.js').RoomList;
var { io } = require("./gameserver.js");

/**
 * @typedef {import ('./Player.js').Player} Player
 */

/**
 * Represents room object
 * 
 * @typedef {Object} Room
 * @property {number} id unique identifier for the room
 * @property {string} name name of the room. displayed in game. does not have to be unique.
 * @property {number} ownerid unique identifier for the room owner (player object)
 * @property {string} ownername display name of the room owner (player object)
 * @property {boolean} loaded status to identify whether a room has loaded or not
 * @property {string} plan contains floorplan of the room.
 * @property {number} type type of the room.
 * @property {number} location location of the room
 * @property {string} description description of the room. Displayed in the navigation.
 * @property {{userid: string,p:Player}} users list of users where the key is user's id and value is the player object.
 * @property {{playerid: string,userid:string}} usersInQueue list of users waiting to enter the room. key and value are both user ids (a bit redundant, option to change in future)
 * @property {{room_furnitureid:number,s:furni}} furniture unique identifier for the room 
 * //TODO: check for bugs the key in furniture is a room_furntiure id or furniture id? 
 */
class Room {
	constructor(id) {

		/**
		 * Used to identify the room
		 * 
		 * @property {number} this.id asdasdasd
		 */
		this.id = id;

		/** 
		 * Name of the room
		 * @type {string}
		 */
		this.name = undefined;

		/** 
		 * @type {number} 
		 * @default undefined by default 
		 */
		this.ownerid = undefined;

		this.ownername = undefined;

		/** @type {boolean} */
		this.loaded = false;

		/** @type {string} */
		this.plan = undefined;

		this.type = undefined;
		this.location = undefined;
		this.description = undefined;

		this.users = {};
		this.usersInQueue = {};
		this.furniture = {};
	}



	/**
	 * Add user to the room.
	 * 
	 * @param {Player} user - Player object to be added to the room.
	 */
	addUser(user) {
		this.usersInQueue[user.id] = user;
		
		if (this.loaded) {
			this.processWaitingQueue();//add user to oThis
		} // else we don't care because once the room is loaded, we force the queue to process..?
		util.log('[ROOM] ID '  + this.id + ' has added user ID '+  user.id + ' to user list.' );
	}


	/**
	 * Processes the queue of users waiting to enter the room.
	 * 
	 * @emits roomDetails room details including the map, start location, type, etc.
	 * @emits playerJoinRoom player joining the room
	 * @emits furniAdded furniture in the room
	 */
	processWaitingQueue() {
		for (var waitingPlayerID in this.usersInQueue) {
			var user = this.usersInQueue[waitingPlayerID];
			user.roomid = this.id;
			user.getSocket().join(this.id);

			user.rowTile = Room.templates[this.type].startrow;
			user.colTile = Room.templates[this.type].startcol;
			//use this, //deprecates user.client.emit('roomMap', oThis.plan); // let the joining player know about the map details
			user.getSocket().emit('roomDetails', { "name": this.name, "ownername": this.ownername, "ownerid": this.ownerid, "type": this.type, "location": this.location, "description": this.description, "map": this.plan, "mapdetails": Room.templates[this.type] });
			
			console.log("debug:0.1");
			//tell new player about existing users in the room.
			console.log(this.users);

			console.log(PlayerList);

			for(var playerID in this.users) {
				var player = PlayerList[this.users[playerID]];
				console.log('Telling player ' + user.displayname + '('+ user.id + ') about ' + player.displayname + '.');
				user.getSocket().emit('playerJoinRoom', player);
			}

			this.users[user.id] = user.id; // add player to this room
			user.getSocket().join(user.roomid);

			io.sockets.in(user.roomid).emit('playerJoinRoom', user); // tell everyone in the room about new user joining (including the new player)

			delete this.usersInQueue[user.id]; // remove player from queue

			// TODO: improvement - send all the furni at once instead of one by one.
			for (var i = 0; i < this.furniture.length; i++) {
				console.log({ "itemid": this.furniture[i].furniid, "direction": this.furniture[i].direction, "col": this.furniture[i].col, "row": this.furniture[i].row });
				user.getSocket().emit('furniAdded', { "itemid": this.furniture[i].furniid, "direction": this.furniture[i].direction, "col": this.furniture[i].col, "row": this.furniture[i].row });
			}
		}
	}



	/**
	 * 
	 * @param {Player} player player to be removed from the room.
	 */
	removePlayer(player) {
		io.sockets.in(player.roomid).emit('playerLeftRoom', player.id);
		if (player.getSocket() != undefined) { // player might've disconnected. | this check may no longer be needed since gameserver.onSocketDisconnect was added. 
			player.getSocket().leave(this.id);
		}
		
		player.roomid = undefined;
		delete this.users[player.id];
	}

	//player user who put down furni, data is info about room and furni being put down
	addFurni(player, data) {
		util.log("[ROOM] ID " + player.roomid + " (owned by " + RoomList[player.roomid].ownerid + ") " + " added furni " + data.itemid + " by user " + player.id);

		if (player.id == RoomList[player.roomid].ownerid) {

			// - Remove this furni from player's inventory
			if (player.inventory.hasItem(data.id, 1)) {
				player.inventory.removeItem(data.id, 1);

				var statement = db.prepare('INSERT INTO room_furniture values (?,?,?,?,?,?,?)');
				statement.run({ 1: null, 2: player.id, 3: player.roomid, 4: data.id, 5: data.row, 6: data.col, 7: data.direction });
				statement.finalize();
				util.log("[ROOM] DB Operation finished. Furniture added.");

				// - Add furni to this room's map plan.
				io.sockets.in(player.roomid).emit('furniAdded', { "itemid": data.id, "direction": data.direction, "col": data.col, "row": data.row });
			} else {
				util.log("[ROOM] FAILED TO ADD FURNITURE - User denied permission");
			}
		} else {
			console.log('someone tried to add furni to a room they dont own.');
		}
	}

	/**
	 * Delete furniture from the player's room. Only supposed to delete if the player is the room owner.
	 * @param {{itemid: number, direction: number, col: number, row: number}} data Details about the furniture to be deleted.
	 * @param {Player} player player (expected to be the room owner) who deleted the furniture
	 */
	deleteFurni(player, data) {
		util.log("[ROOM] ID " + player.roomid + " (owned by " + this.ownername + this.ownerid + ") " + " deleted furni " + data.itemid + " by user " + player.id);
		if (player.id == this.ownerid) {
			// DELETE FROM table 			WHERE search_condition 			ORDER BY criteria 			LIMIT row_count OFFSET offset;
			// - Remove this furni from player's inventory
			util.log(data);
			var statement = db.prepare("DELETE FROM room_furniture WHERE furniowner = $furniowner AND roomid = $roomid AND furniid = $furniid AND row = $row AND col = $col AND direction = $direction");
			//CREATE TABLE room_furniture(id integer primary key autoincrement, furniowner integer, roomid integer, furniid integer, row integer, col integer, direction integer);
			var args = {
				'$furniowner': this.ownerid,
				'$roomid': this.id,
				'$furniid': data.itemid,
				'$col': data.col,
				'$row': data.row,
				'$direction': data.direction
			};

			console.log(args);
			statement.run(args);
			statement.finalize();
			util.log("[ROOM] DB Operation finished. Furniture added.");

			io.sockets.in(player.roomid).emit('furniRemoved', { "itemid": data.itemid, "direction": data.direction, "col": data.col, "row": data.row });

		}
	}

	/**
	 * @field statement 
	 * @param {any} player
	 * @param {any} data
	 */
	rotateFurni(player, data) {
		//{ playerId: game.characterHandler.player.id, roomId: game.map.id, itemid: self.selectedEntity.id, col: self.selectedEntity.currentTileCol, row: self.selectedEntity.currentTileRow, direction: self.selectedEntity.direction }
		util.log("[ROOM] ID " + this.id + " (owned by " + this.ownername +":"+ this.ownerid + ") " + " rotate furni " + data.itemid + " by user " + player.id);
		if (player.id == RoomList[player.roomid].ownerid) {
			var statement = db.prepare("update room_furniture set direction = $newDirection WHERE roomid = $roomid AND furniid = $furniid AND row = $row AND col = $col AND direction = $oldDirection");
			var args = {
				'$newDirection': data.new_direction,
				'$roomid': this.id,
				'$furniid': data.itemid,
				'$col': data.col,
				'$row': data.row,
				'$oldDirection': data.old_direction
			};

			statement.run(args);
			statement.finalize();
			util.log("[ROOM] DB Operation finished. Furniture rotated.");
			io.sockets.in(player.roomid).emit('furniRotated', { "itemid": data.itemid, "old_direction": data.old_direction, "new_direction": data.new_direction, "col": data.col, "row": data.row });

		}
	}


	/**
	 * @method	load
	 * Loads a player.
	 * @callback 
	 */
	load() {
		db.serialize( () => {
			//id INTEGER AUTO_INCREMENT, playerid int, roomtype int, location int, name text, description text, map text
			db.each("SELECT r.id as id, r.playerid as playerid, p.displayname as ownername, r.roomtype as roomtype,"
				+ "r.description as description, r.location as location, r.name as name, r.map as map FROM rooms as r" 
				+ " INNER JOIN players p on p.id = r.playerid where r.id = '" + this.id + "' limit 1;",
			(err, row) => {
				if (err) {
					console.log('*******ERRORRRR!!!!*********************' + err);
					RoomList[this.id] = undefined;
				}
				this.id = row.id;
				this.ownerid = row.playerid;
				this.ownername = row.ownername;
				this.name = row.name;
				this.description = row.description;
				this.type = row.roomtype;
				this.location = row.location;

				this.plan = JSON.parse(row.map);
				this.loaded = true;
				RoomList[this.id] = this;
				}, () => { this.loadFurniture(); } );
		});
	}
	
	loadFurniture() {
		//util.log("load funri = " + util.inspect(arguments, {depth:1, colors:true}));

		var t = db.all("SELECT * FROM room_furniture where roomid='" + this.id + "'", (err, rows) => { this.furnitureLoaded(err, rows); } );
	}
	
	furnitureLoaded(err, rows) {
		if (err) {
			console.log('*******ERRORRRR!!!!*********************' + err);
		}
		console.log(rows);
		this.furniture = rows;
		this.processWaitingQueue();
	}

	waitingToEnter(player) {
		this.usersInQueue[player.id] = player; // this player now wants to join the room
		
		this.processWaitingQueue();
	}
	
	isLoaded() {
		return this.loaded;
	}


};

Room.templates = {
	"1": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
	"2": { "img": null, "imgx": 15, "imgy": 15, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 8, "placementx": -34, "placementy": -2 },
	"3": { "img": null, "imgx": 150, "imgy": 30, "startrow": 5, "startcol": 3, "max_col": 6, "max_row": 6, "placementx": -48, "placementy": 13 },
	"4": { "img": null, "imgx": 10, "imgy": 2, "startrow": 9, "startcol": 3, "max_col": 10, "max_row": 10, "placementx": -44, "placementy": -86 }
	//"e": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
	//"f": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
	//"g": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
	//"h": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 }
}

Room.plans = {
	// user rooms
	"1": '[["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"]]',
	"2": '[["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"]]',
	"3": '[["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01"]]',
	"4": '[["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01","tile01"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile00","tile00","tile00","tile00"],["tile00","tile00","tile00","tile00","tile01","tile01","tile01","tile01","tile01","tile01","tile00","tile00","tile00","tile00"]]',
	"5": '',
	"7": '',
	"8": ''
	// TODO: public room TBD below.

}

module.exports = { class: Room };