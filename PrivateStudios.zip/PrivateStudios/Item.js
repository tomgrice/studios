var util = require("util");
module.exports = Item;

function Item(id, amount) {
	this.id = id;
	this.amount = amount;
	//inventory icon //maybe 1 image for catalog ?
	if(id != -1 && amount != -1) { 
		util.log("[SYSTEM] Created " + amount + " of ItemID " + id + ".");
	}
}