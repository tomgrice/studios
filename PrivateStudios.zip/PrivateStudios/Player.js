'use strict';

var util = require("util");
var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('./test.db');
var Inventory = require('./Inventory.js');
var ServerVariables = require('./ServerVariables.js');
var PlayerList = ServerVariables.PlayerList;
var RoomList = ServerVariables.RoomList;
var { io } = require("./gameserver.js");

/**
 * @file Describes a Player object at the server layer.
 * @author unnecessarilyRedundant <discorduser>
 */

/**
 * @typedef {import ('./Room.js').Room} Room
 */

/**
 * Describes a Player object.
 * 
 * @typedef {Object} Player
 * @property {number} id - Unique identifier for a player.
 * @property {string} tempID - Unique identifier for a player that is randomly generated for pre-login references.
 * @property {number} roomid - Unique identifier for the room that a player is currently in.
 * @property {string} username - uniquely identify the user so they can login. This field is not shown to other players.
 * @property {string} displayname - uniquely identify the user inside the game. This field is shown to other players.
 * @property {boolean} isLoaded - status of whether or not the player has loaded their account
 * @property {Inventory} inventory - Inventory object used to hold a player's items like furniture.
 * @property {number} rowTile - row coordinate of the tile the player is on.
 * @property {number} colTile - column coordinate of the tile the player is on.
 * @property {number} money - amount of money the user has.
 * @property {{body: Array<string>, chest: Array<string>, legs: Array<string>, eye: Array<string>, face: Array<string>, hair: Array<string>, head: Array<string>, lefthand: Array<string>, leftsleeve: Array<string>, righthand: Array<string>, rightsleeve: Array<string>, shoes: Array<string>}} bodyparts type of parts in player body
 */

class Player {

    /**
     * Creates a new Player.
     * 
     * @class Player p
     */
    constructor() {
        /**
         * Unique identifier for a player.
         * @type {number}
         */
        this.id = undefined;

        /**
         * Unique identifier for a player that is randomly generated for pre-login references.
         * @type {number}
         */
        this.tempID = this.generateUid();

        /**
         * Unique identifier for the room that a player is currently in.
         * @type {number}
         */
        this.roomid = undefined; 

        /**
         * uniquely identify the user so they can login. This field is not shown to other players.
         * Supposed to be used to login.
         * @type {string}
         */
        this.username = undefined;

        /**
         * uniquely identify the user inside the game. This field is shown to other players.
         * @type {string}
         */
        this.displayname = undefined;

        /**
         * status of whether or not the player has loaded their account
         * @type {number}
         */
        this.isLoaded = false;

        /**
         * Parts in player's body.
         * 
         * @type {{body: Array<string>, chest: Array<string>, legs: Array<string>, eye: Array<string>, face: Array<string>, hair: Array<string>, head: Array<string>, lefthand: Array<string>, leftsleeve: Array<string>, righthand: Array<string>, rightsleeve: Array<string>, shoes: Array<string>}}
         */
        this.bodyparts = {};

        /**
         * Inventory object used to hold a player's items like furniture.
         * 
         * @type {Inventory}
         */
        this.inventory = undefined;

        /**
         * row (x) coordinate of the tile the player is on.
         * 
         * @type {number} 
         */
        this.rowTile = undefined;

        /**
         * column (y) coordinate of the tile the player is on.
         * 
         * @type {number} 
         */
        this.colTile = undefined;

        /**
         * amount of money the user has.
         * 
         * @type {number} 
         */
        this.money = undefined;
    }

    /**
     * generates a temporary id for the player to use pre-login
     * 
     * @method: generateUid
     * @param {string} separator string used to delimit the substrings
     * @returns {string} a delimited identifier delimeted by 4 seperators 
     */
    generateUid(separator) {
        var delim = separator || "-";
        function S4() {
            return (((1 + Math.random()) * 65536) | 0).toString(16).substring(1);
        }
        //before reutrning this ID, store this object in uninitialized players object, keyed on this unique id.
        return (S4() + S4() + delim + S4() + delim + S4() + delim + S4() + delim + S4() + S4() + S4());
    }


    /**
     * load my player based on user and pass. Then load user's inventory.
     * 
     * @method load
     * @param {string} username 
     * @param {string} password
     */
    // TODO: sanitize these parameters
    load(username, password) {
        db.serialize(() => {
            db.each("SELECT id, username, status, money, displayname, body, chest, legs, eye, face, hair, head, lefthand, leftsleeve, righthand, rightsleeve, shoes FROM players "
                + "where username='" + username + "' AND password='" + password + "' limit 1",
                (err, row) => { // using arrow method to bind to 'this' to player instance instead of statement {} object.
                    //console.log([err, row]);
                    this.id = row.id;
                    this.username = row.username;
                    this.displayname = row.displayname;
                    this.money = row.money;
                    this.status = row.status;
                    this.bodyparts["body"] = row.body;
                    this.bodyparts["chest"] = row.chest;
                    this.bodyparts["eye"] = row.eye;
                    this.bodyparts["face"] = row.face;
                    this.bodyparts["hair"] = row.hair;
                    this.bodyparts["head"] = row.head;
                    this.bodyparts["legs"] = row.legs;
                    this.bodyparts["lefthand"] = row.lefthand;
                    this.bodyparts["leftsleeve"] = row.leftsleeve;
                    this.bodyparts["righthand"] = row.righthand;
                    this.bodyparts["rightsleeve"] = row.rightsleeve;
                    this.bodyparts["shoes"] = row.shoes;

                    util.log('Player.load(): ID_' + this.id + ", DISPLAY_" + this.displayname + ', USER_' + this.username + ' has logged in. Attempting to load inventory.');
                    this.inventory = new Inventory(this.id);
                    this.inventory.load(() => { this.acceptLogin(); } ); // first load inventory, then accept login as callback.

                    });
        });
    }

    /**
     * Accept the user's login
     * @fires Player#event:loginAccepted
     */
    acceptLogin() {
        this.isLoaded = true;
        PlayerList[this.id] = this;

        /**
         * User Login Accepted event
         *
         * @event Player#event:loginAccepted
         * @type {object}
         * @property {number} id - Identifier for the user we're accepting the login for.
         * @property {number} status - account status of the user.
         * @property {number} money - amount of money the user has at login.
         * @property {string} username - amount of money the user has at login.
         * @property {string} displayname - amount of money the user has at login.
         * @property {number} bodyparts - amount of money the user has at login.
         * @property {Inventory} inventory - amount of money the user has at login.
         */
        this.getSocket().emit("loginAccepted",
            {
                id: this.id,
                status: this.status,
                money: this.money,
                username: this.username,
                displayname: this.displayname,
                bodyparts: this.bodyparts,
                inventory: this.inventory.items
            });
    };


    /**
     * Fetches the player's client.
     * @returns player's socket used communicate with the client
     */
    getSocket() {
        return io.sockets.sockets.get(this.clientid);
    }


    /**
     * Move a player to a new destination within the same room.
     * 
     * @param {number} col
     * @param {number} row
     * @emits Player#playerMoving
     */
    move(col, row) {
        util.log("[MOVE] Moving " + this.displayname + "(" + this.id + ")" + " from (" + this.colTile + "," + this.rowTile + ") to (" + col + "," + row + ").");
        this.rowTile = row;
        this.colTile = col;
        /**
         * @event Player#playerMoving  sends client new coordinates of a player to everyone in the room
         */
        io.sockets.in(this.roomid).emit('playerMoving', this.id, this.colTile, this.rowTile);
    }


    /**
     * Send a player outside the room they are currently in.
     * 
     * @method leaveRoom
     */
    leaveRoom() {
        if (this.roomid != undefined) {
            util.log("[Player] " + this.id + " is asking to leave room " + this.roomid + ".");
            RoomList[this.roomid].removePlayer(this);
        } else {
            util.log("[Player] " + this.id + " tried to leave room that was undefined.");
        }
    }

    /**
     * Create a new studio for the user
     * 
     * @param {{type: number, location: number, name: string, description: string}} studio details of the studio being requested.
     */
    createRoom(studio) {
        // CREATE TABLE rooms(id INTEGER AUTO_INCREMENT, playerid int, roomtype int, location int, name text, description text, map text);
        var statement = db.prepare("INSERT INTO rooms(playerid, roomtype, location, name, description, map) VALUES($playerid, $roomtype, $location, $name, $description, $map);");

        var args = {
            '$playerid': this.id,
            '$roomtype': studio.type,
            '$location': studio.location,
            '$name': studio.name,
            '$description': studio.description,
            '$map': Room.plans[studio.type]
        };
        statement.run(args);
        statement.finalize();
        console.log([args, statement]);
        util.log("[ROOM] DB Operation finished. room added.");
    }


    /**
     * Enables a user to join a room.
     * The user leaves previous room if they were already in a room.
     * 
     * @param {number} roomid   - id of the room to join
     */
    joinRoom(roomid) {
        util.log('User ID ' + this.id + ' is joining room ' + roomid + '.');
        this.leaveRoom(); // leave the previous room first. leaveroom method tests if 
        this.roomid = roomid;
    };
}

module.exports = { class: Player };