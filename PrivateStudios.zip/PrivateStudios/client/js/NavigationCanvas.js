
function NavigationCanvas() {
	self = this;
	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
	this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI NavigationCanvas");

	this.div.style.left = "0px";
	this.div.style.top = "0px";
	this.div.style.position = "absolute";

	this.navigationStage = document.createElement("canvas");
	this.navigationStage.setAttribute("name", "navigationCanvas");
	this.navigationStage.setAttribute("id", "navigationCanvas");
	this.navigationStage.setAttribute("class", "NavigationCanvas");
	this.navigationStage.setAttribute("width", 316);
	this.navigationStage.setAttribute("height", 415);
	this.navigationStage.style.position = "absolute";
	this.navigationStage.style.left = "0px";
	this.navigationStage.style.top = "0px";
	
	this.ctx = this.navigationStage.getContext('2d');
	this.bg = new Image();
	this.bg.src = '../img/ui/navigator_ref.png';

	this.tab_bg_publicview = new Image();
	this.tab_bg_publicview.src = '../img/ui/nav.tab.publicview.png';

	this.tab_bg_userstudios = new Image();
	this.tab_bg_userstudios.src = '../img/ui/nav.tab.userstudios.png';

	this.tab_bg_usersearch = new Image();
	this.tab_bg_usersearch.src = '../img/ui/nav.tab.usersearch.png';




	this.tab_bg_modifystudios = new Image();
	this.tab_bg_modifystudios.src = '../img/ui/nav.tab.userstudios.modifyyourstudiowindow.png';

	this.userstudios_showactive = new Image();
	this.userstudios_showactive.src = '../img/ui/nav.studios.showactivestudios.png';

	this.userstudios_showmy = new Image();
	this.userstudios_showmy.src = '../img/ui/nav.studios.showmystudios.png';

	this.searchbar = new Image();
	this.searchbar.src = '../img/ui/nav.searchbutton.png';

	//is this even needed?
	this.go_into_studio_btn = new Image();
	this.go_into_studio_btn.src = '../img/ui/nav.studios.studio_go.png';

	//is this even needed?
	this.modify_my_studio = new Image();
	this.modify_my_studio.src = '../img/ui/nav.studios.modifymystudio.png';


	this.div.appendChild(this.navigationStage);

	this.selectedTab = 'publicview';

	this.btn_tab_publicView = document.createElement("input");
	this.btn_tab_publicView.setAttribute("value", " ");
	this.btn_tab_publicView.setAttribute("type", "button");
	this.btn_tab_publicView.setAttribute("class", "NavigationCanvas btn_browseRoomList");
	this.btn_tab_publicView.setAttribute("name", "btn_browseRoomList");
	this.btn_tab_publicView.setAttribute("id", "btn_browseRoomList");
	this.btn_tab_publicView.setAttribute("onClick", "game.navigation.setSelectedTab('publicview');");
	this.btn_tab_publicView.style.position = "inherit";
	this.btn_tab_publicView.style.left = "14px";
	this.btn_tab_publicView.style.top = "35px";
	this.btn_tab_publicView.style.width = '90px';
	this.btn_tab_publicView.style.height = '25px';
	this.btn_tab_publicView.style.background = "transparent";
	this.btn_tab_publicView.style.border = "none";
	this.btn_tab_publicView.style.outline = "none";
	this.div.appendChild(this.btn_tab_publicView);

	

	this.btn_tab_userstudios = document.createElement("input");
	this.btn_tab_userstudios.setAttribute("value", " ");
	this.btn_tab_userstudios.setAttribute("type", "button");
	this.btn_tab_userstudios.setAttribute("class", "NavigationCanvas btn_tab_userstudios");
	this.btn_tab_userstudios.setAttribute("name", "btn_tab_userstudios");
	this.btn_tab_userstudios.setAttribute("id", "btn_tab_userstudios");
	this.btn_tab_userstudios.setAttribute("onClick", "game.navigation.setSelectedTab('userstudios');");
	this.btn_tab_userstudios.style.position = "inherit";
	this.btn_tab_userstudios.style.left = "107px";
	this.btn_tab_userstudios.style.top = "35px";
	this.btn_tab_userstudios.style.width = '100px';
	this.btn_tab_userstudios.style.height = '25px';
	this.btn_tab_userstudios.style.background = "transparent";
	this.btn_tab_userstudios.style.border = "none";
	this.btn_tab_userstudios.style.outline = "none";
	this.div.appendChild(this.btn_tab_userstudios);


	
	this.btn_tab_usersearch = document.createElement("input");
	this.btn_tab_usersearch.setAttribute("value", " ");
	this.btn_tab_usersearch.setAttribute("type", "button");
	this.btn_tab_usersearch.setAttribute("class", "NavigationCanvas btn_tab_usersearch");
	this.btn_tab_usersearch.setAttribute("name", "btn_tab_usersearch");
	this.btn_tab_usersearch.setAttribute("id", "btn_tab_usersearch");
	this.btn_tab_usersearch.setAttribute("onClick", "game.navigation.setSelectedTab('usersearch');");
	this.btn_tab_usersearch.style.position = "inherit";
	this.btn_tab_usersearch.style.left = "210px";
	this.btn_tab_usersearch.style.top = "35px";
	this.btn_tab_usersearch.style.width = '90px';
	this.btn_tab_usersearch.style.height = '25px';
	this.btn_tab_usersearch.style.background = "transparent";
	this.btn_tab_usersearch.style.border = "none";
	this.btn_tab_usersearch.style.outline = "none";
	this.div.appendChild(this.btn_tab_usersearch);
	

	

	/*
	this.select = document.createElement("select");
	this.select.setAttribute("name", "ListOfRooms");
	this.select.setAttribute("class", "browseRoomListFields");
	this.select.setAttribute("id", "ListOfRooms");
	this.select.setAttribute("size", "9");
	this.select.style.position = "inherit";
	this.select.style.width = "272px";
	this.select.style.height = "99px";
	this.select.style.left = "23px";
	this.select.style.top = "95px";
	this.select.style.border = "none";
	this.select.style.border = "none";
	this.select.style.outline = "none";
	this.select.style.background = "transparent";
	this.select.style.fontSize = "8pt";
	this.select.display = 'none';
	//this.select.style.userSelect.webkitAppearance= "none";
	this.select.style.webkitAppearance = "none";
	this.select.hidden = 'true'; // start off hidden.
	this.div.appendChild(this.select);

	
	
	
	this.select.ondblclick = function() {
		socket.emit("RoomEnter", this.options[this.selectedIndex].value);
		game.navigation.close();
		game.lobby.close();
		console.log('clear!');
	};
	*/
	this.selectedRoom = null;

	/*
	this.select.onchange = function () {
		console.log(this.value);
		if (this.value != null && this.value != '') {
			self.selectedRoomId = this.value;
			$('.setupyourstudio_button').hide();
			$('.modify_studio').show();
			$('.gointo_studio').show();


			//self.selectedRoomId = this.getAttribute('roomid');
			self.selectedRoomName = this.select[this.select.selectedIndex].dataset["roomname"];
			self.selectedRoomPlayerCount = this.select[this.select.selectedIndex].dataset["roomplayercount"];
			self.selectedRoomOwner = this.select[this.select.selectedIndex].dataset["roomowner"];
			self.selectedRoomDescription = this.select[this.select.selectedIndex].dataset["roomdescription"];
		}
		
	};


	this.select.onclick = function () {
		console.log(this.value);
		if (this.value != null && this.value != '') {
			self.selectedRoomId = this.value;
			$('.setupyourstudio_button').hide();
			$('.modify_studio').show();
			$('.gointo_studio').show();

			//self.selectedRoomId = this.getAttribute('roomid');
			self.selectedRoomName = this.select[this.select.selectedIndex].dataset["roomname"];
			self.selectedRoomPlayerCount = this.select[this.select.selectedIndex].dataset["roomplayercount"];
			self.selectedRoomOwner = this.select[this.select.selectedIndex].dataset["roomowner"];
			self.selectedRoomDescription = this.select[this.select.selectedIndex].dataset["roomdescription"];
		}
	}*/
	
	//------------ Find rooms:
	var btn_searchRoom = document.createElement("input");
	btn_searchRoom.setAttribute("value", "Find...");
	btn_searchRoom.setAttribute("type", "button");
	btn_searchRoom.setAttribute("class", "NavigationCanvas");
	btn_searchRoom.setAttribute("name", "btn_searchRoom");
	btn_searchRoom.setAttribute("id", "btn_searchRoom");
	btn_searchRoom.setAttribute("onclick", "alert('This feature is currently unavailable.')");
	btn_searchRoom.style.position = "inherit";
	btn_searchRoom.style.left = 110 + 90 + 10 + "px";
	btn_searchRoom.style.top = "120px";
	//this.div.appendChild(btn_searchRoom);  // Enable this when the feature is available.

	
	this.toggleDisplay = function() {
		console.log('toggleDisplay called?');
		if (!$('.NavigationCanvas').is(":visible")) {
			//socket.emit('RoomRequest');


			

			$('.NavigationCanvas').show();

			$('.showActiveStudioHolder').hide();
			$('.showMyStudioHolder').hide();

			$('.createRoomField').hide();

			$('.studioName').hide();
			$('.studioDescription').hide();

			this.setSelectedTab('publicview');

		} else {
			this.setSelectedTab('publicview');
			$('.NavigationCanvas').hide();

			
		}

		$('.showActiveStudioHolder').hide();
		$('.showMyStudioHolder').hide();
	}
	
	this.close = function() {
		console.log('NAV close called');
		$('.NavigationCanvas').hide();
	}

	this.hideCanvas = function () {
		$('.NavigationCanvas').hide();
	}

	this.showCanvas = function() {
		console.log('show navigation called');
			//socket.emit('RoomRequest');
		$('.NavigationCanvas').show();
		$('.createRoomField').hide();

		$('.studioName').hide();
		$('.studioDescription').hide();

		$('.showMyStudioHolder').hide();
		$('.showActiveStudioHolder').hide();
		
	}
	
	
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}
	
	this.mainDiv.appendChild(this.div);


	this.tab_nav_setupyourstudio = new Image();
	this.tab_nav_setupyourstudio.src = '../img/ui/nav.tab.userstudios.setupyourstudio.png';

	this.tab_nav_userstudio_helpmsg = new Image();
	this.tab_nav_userstudio_helpmsg.src = '../img/ui/nav.tab.userstudios.helpmsg.png';


	this.tab_nav_userstudio_createbg = new Image();
	this.tab_nav_userstudio_createbg.src = '../img/ui/nav.tab.userstudios.setupyourstudiowindow.png';

	this.checkbox_selected = new Image();
	this.checkbox_selected.src = '../img/ui/nav.tab.userstudios.setupyourstudio_checkbox.png';

	this.tab_nav_userstudio_selectedroom = new Image();
	this.tab_nav_userstudio_selectedroom.src = '../img/ui/nav.tab.userstudios.selectedmystudio.png';

	this.tab_nav_userstudio_selectedactiveroom = new Image();
	this.tab_nav_userstudio_selectedactiveroom.src = '../img/ui/nav.tab.userstudios.selectedactivestudio.png';

	//nav.tab.userstudios.selectedmystudio.png; nav.tab.userstudios.selectedactivestudio.png

	this.draw = function () {
		this.ctx.drawImage(this.bg, 0, 0);


		switch (self.selectedTab) {
			case 'publicview':
				this.ctx.drawImage(this.tab_bg_publicview, 12, 34);
				 
				break;

			////userstudios_showActiveStudios	userstudios_showMyStudios	userstudios_searchBtn

			case 'usersearch':
				this.ctx.drawImage(this.tab_bg_usersearch, 13, 35);
				break;
			
			case 'userstudios_showActiveStudios':
			//

			case 'userstudios_showMyStudios':

			case 'userstudios_searchBtn':
				

			case 'userstudios':
				this.ctx.drawImage(this.tab_bg_userstudios, 12, 34);
				

				this.ctx.drawImage(this.userstudios_showactive, 17, 73);
				this.ctx.drawImage(this.userstudios_showmy, 154, 73);
				this.ctx.drawImage(this.searchbar, 267, 73);


				this.ctx.drawImage(this.tab_nav_setupyourstudio, 80, 363);
				if (self.selectedRoomId == null && self.selectedRoomId == undefined) {
					this.ctx.drawImage(this.tab_nav_userstudio_helpmsg, 33, 306);
				} else {
					//console.log('selected room' + self.selectedRoom);
					if (self.selectedTab == 'userstudios_showActiveStudios') {
						this.ctx.drawImage(this.tab_nav_userstudio_selectedactiveroom, 13, 266);

					} else {
						this.ctx.drawImage(this.tab_nav_userstudio_selectedroom, 13, 266);

					}
					
					this.ctx.font = 'bold 10pt Calibri';
					this.ctx.fillStyle = "#614028";

					/*self.selectedRoomId = this.getAttribute('roomid');
					self.selectedRoomName = this.getAttribute('roomname');
					self.selectedRoomPlayerCount = this.getAttribute('playercount');
					self.selectedRoomOwner = this.getAttribute('roomowner');
					self.selectedRoomDescription = this.getAttribute('description');

					//$('.setupyourstudio_button').hide();
					//$('.modify_studio').show();
					//$('.gointo_studio').show();
					*/

					this.ctx.fillText(self.selectedRoomName + " (" + self.selectedRoomPlayerCount + "/25)", 32, 314);
					this.ctx.fillText("owner : " + self.selectedRoomOwner, 32, 327);

					this.ctx.font = '8pt Calibri';
					this.ctx.fillText(self.selectedRoomDescription, 32, 342);

					//this.options[this.selectedIndex].value
					//game.navigation.select[game.navigation.select.selectedIndex].dataset["roomname"]



					/*self.selectedRoomId = this.getAttribute('roomid');
					self.selectedRoomName = this.getAttribute('roomname');
					self.selectedRoomPlayerCount = this.getAttribute('playercount');
					self.selectedRoomOwner = this.getAttribute('roomowner');
					self.selectedRoomDescription = this.getAttribute('description');

					//$('.setupyourstudio_button').hide();
					//$('.modify_studio').show();
					//$('.gointo_studio').show();
					*/

					
					//this.options[this.selectedIndex].value
					//game.navigation.select[game.navigation.select.selectedIndex].dataset["roomname"]






				}

				break;

			case 'userstudios_modifyMyStudio':
				//this.ctx.drawImage(this.tab_nav_userstudio_createbg, 8, 25);
				this.ctx.drawImage(this.tab_bg_modifystudios, 13, 35);
				break;

			case 'createstudio':
				this.ctx.drawImage(this.tab_nav_userstudio_createbg, 8, 25);
				switch (self.studioType) {
					case 1:
						this.ctx.drawImage(this.checkbox_selected, 47, 201);
						break;
					case 2:
						this.ctx.drawImage(this.checkbox_selected, 113, 201);
						break;
					case 3:
						this.ctx.drawImage(this.checkbox_selected, 179, 201);
						break;
					case 4:
						this.ctx.drawImage(this.checkbox_selected, 245, 201);
						break;
					case 5:
						this.ctx.drawImage(this.checkbox_selected, 51, 269);
						break;
					case 6:
						this.ctx.drawImage(this.checkbox_selected, 146, 269);
						break;
					case 7:
						this.ctx.drawImage(this.checkbox_selected, 241, 269);
						break;
					default:
						this.ctx.drawImage(this.checkbox_selected, 47, 201);
						break;
				}

				switch (self.studioLocation) {
					case 1:
						this.ctx.drawImage(this.checkbox_selected, 30, 299);
						break;
					case 2:
						this.ctx.drawImage(this.checkbox_selected, 30, 317);
						break;
					case 3:
						this.ctx.drawImage(this.checkbox_selected, 30, 335);
						break;
					case 4:
						this.ctx.drawImage(this.checkbox_selected, 30, 355);
						break;
					case 5:
						this.ctx.drawImage(this.checkbox_selected, 140, 300);
						break;
					case 6:
						this.ctx.drawImage(this.checkbox_selected, 140, 318);
						break;
					case 7:
						this.ctx.drawImage(this.checkbox_selected, 140, 336);
						break;
					case 8:
						this.ctx.drawImage(this.checkbox_selected, 140, 354);
						break;
					default:
						this.ctx.drawImage(this.checkbox_selected, 30, 299);
						break;

				}

				//end of create studio
				break;

			default:
				break;

		}

	}


	this.createClickAble = function (name, x, y, w, h, onClick, hoverable) {
		onClick = (typeof onClick === 'undefined') ? "console.log('" + name + "' button clicked in catalogue.)" : onClick;
		hoverable = (typeof hoverable === 'undefined') ? false : hoverable;

		var element = document.createElement("input");
		element.setAttribute("type", "button");
		element.setAttribute("value", "");
		element.setAttribute("id", name);
		element.setAttribute("name", name);
		//element.setAttribute("class", "" + name); // keep for testing
		element.setAttribute("class", "transparentStyling " + name);
		element.setAttribute("onclick", onClick);
		element.style.position = "inherit";
		element.style.left = x + "px";
		element.style.width = w + "px";
		element.style.height = h + "px";
		element.style.top = y + "px";
		element.hidden = 'true';
		this.div.appendChild(element);

		if (hoverable) {
			element.onmouseover = function (event) {
				self.hoveringOn = name;
				console.log('hovering on navigation ' + name + ' button ');

			}
			element.onmouseleave = function (event) {
				self.hoveringOn = '';
				console.log('stopped hovering on navigation ' + name + ' button ');
			}
		}
		return element;
	};

	

	this.setSelectedTab = function (newTab) {
		self.selectedTab = newTab;
		console.log('set new tab as ' + self.selectedTab);

		switch (self.selectedTab) {
			case 'publicview':

				$('.showActiveStudioHolder').hide();
				$('.showMyStudioHolder').hide();
				$('.btn_browseRoomList').show();
				$('.btn_tab_userstudios').show();

				//self.selectedTab = 'publicview';
				$('.createRoomField').hide();
				//$('.browseRoomListFields').show();

				$('.showActiveStudios').hide();
				$('.showMyStudios').hide();
				$('.searchBtn').hide();

				$('.browseRoomListFields').hide();
				$('.setupyourstudio_button').hide();

				$('.studioName').hide();
				$('.studioDescription').hide();

				$('.modify_studio').hide();
				$('.gointo_studio').hide();

				self.selectedRoomId == null;

				console.log('clicked pub view');
				break;

			case 'usersearch':
				$('.modify_studio').hide();
				$('.gointo_studio').hide();
				$('.showActiveStudioHolder').hide();
				$('.showMyStudioHolder').hide();
				$('.showActiveStudios').hide();
				$('.showMyStudios').hide();

				break;
			//browseRoomListFields
			case 'userstudios_showActiveStudios':
				self.selectedRoomId = null;

				$('.browseRoomListFields').hide();
				$('.setupyourstudio_button').show();
				if (document.getElementsByClassName('showActiveStudioHolder')[0].getElementsByClassName('studioHolder')[0] != undefined) {
					$('.showActiveStudioHolder').show();
				} else {
					$('.showActiveStudioHolder').hide();
				}
				
				$('.modify_studio').hide();
				$('.gointo_studio').hide();
				$('.showMyStudioHolder').hide();

				socket.emit('ActiveRoomRequest');

				this.addToUserStudioList("active", this.roomList);


				break;
			case 'userstudios_showMyStudios':
				self.selectedRoomId = null;

				$('.setupyourstudio_button').show();

				$('.modify_studio').hide();
				$('.gointo_studio').hide();
				$('.browseRoomListFields').hide();

				$('.showActiveStudioHolder').hide();
				
				

				if (document.getElementsByClassName('showMyStudioHolder')[0].getElementsByClassName('studioHolder')[0] != undefined) {
					$('.showMyStudioHolder').show();
				} else {
					$('.showMyStudioHolder').hide();
				}

				socket.emit('RoomRequest');

				break;
			case 'userstudios_searchBtn':
				self.selectedRoomId = null;

				$('.browseRoomListFields').hide();
				$('.showMyStudioHolder').hide();
				$('.showActiveStudioHolder').hide();
				break;

			case 'userstudios_modifyMyStudio':

			

				$('.showMyStudioHolder').hide();
				$('.showActiveStudioHolder').hide();
				$('.btn_browseRoomList').hide();
				$('.btn_tab_userstudios').hide();

				$('.modify_ok').show();
				$('.modify_cancel').show();
				$('.modify_delete').show();


				$('.showActiveStudios').hide();
				$('.showMyStudios').hide();
				$('.searchBtn').hide();
				$('.browseRoomListFields').hide();
				$('.modify_studio').hide();
				$('.gointo_studio').hide();
				
				
				$('.studioDescription').show();
				$('.studioName').show();

				$('.studioDescription').val(self.selectedRoomDescription);

				//self.selectedRoomId; 
				//;self.selectedRoomPlayerCount; self.selectedRoomOwner;
				$('.studioDescription').css('top', "145px");
				

				$('.studioName').val(self.selectedRoomName);
				$('.studioName').css('top', "95px");


				break;

			case 'userstudios':
				self.selectedRoomId = null;

				$('.btn_browseRoomList').show();
				$('.btn_tab_userstudios').show();
				$('.showMyStudioHolder').hide();
				self.selectedRoom = null;
				$('.modify_ok').hide();
				$('.modify_cancel').hide();
				$('.modify_delete').hide();



				$('.modify_studio').hide();
				$('.gointo_studio').hide();


				$('.setupyourstudio_cancel_button').hide();
				$('.setupyourstudio_button').show();

				$('.createRoomField').hide();
				console.log('clicked userstudios view');

				$('.showActiveStudios').show();
				$('.showMyStudios').show();
				$('.searchBtn').show();


				$('.browseRoomListFields').hide();
				$('.studioName').hide();
				$('.studioDescription').hide();

				$('.setupstudio_type1').hide();
				$('.setupstudio_type2').hide();
				$('.setupstudio_type3').hide();
				$('.setupstudio_type4').hide();
				$('.setupstudio_type5').hide();
				$('.setupstudio_type6').hide();
				$('.setupstudio_type7').hide();
				$('.setupstudio_ok').hide();

				$('.studioDescription').hide();
				$('.studioName').hide();

				$('.setupstudio_locMiami').hide();
				$('.setupstudio_locMombasa').hide();
				$('.setupstudio_locNewYork').hide();
				$('.setupstudio_locLondon').hide();
				$('.setupstudio_locSeattle').hide();
				$('.setupstudio_locSydney').hide();
				$('.setupstudio_locTokyo').hide();
				$('.setupstudio_locRioDeJaneiro').hide();
				this.setSelectedTab('userstudios_showActiveStudios');
				//setupyourstudio_button
				break;

			case 'createstudio':

				$('.showActiveStudioHolder').hide();
				$('.showMyStudioHolder').hide();
				$('.showActiveStudios').hide();
				$('.showMyStudios').hide();
				$('.searchBtn').hide();

				$('.browseRoomListFields').hide();
				$('.setupyourstudio_button').hide();
				$('.setupyourstudio_cancel_button').show();
				$('.studioDescription').show();
				$('.studioName').show();

				
				$('.studioName').css('top', "70px");

				$('.studioDescription').css('top', "105px");

				$('.setupstudio_type1').show();
				$('.setupstudio_type2').show();
				$('.setupstudio_type3').show();
				$('.setupstudio_type4').show();
				$('.setupstudio_type5').show();
				$('.setupstudio_type6').show();
				$('.setupstudio_type7').show();
				$('.setupstudio_ok').show();

				$('.setupstudio_locMiami').show();
				$('.setupstudio_locMombasa').show();
				$('.setupstudio_locNewYork').show();
				$('.setupstudio_locLondon').show();
				$('.setupstudio_locSeattle').show();
				$('.setupstudio_locSydney').show();
				$('.setupstudio_locTokyo').show();
				$('.setupstudio_locRioDeJaneiro').show();


				break;

		}

	}

	this.studioName = document.createElement("input");
	this.studioName.setAttribute("type", "text");
	this.studioName.setAttribute("class", "NavigationCanvas studioName");
	this.studioName.setAttribute("name", "studioName");
	this.studioName.setAttribute("id", "studioName");
	this.studioName.style.color = "White";
	this.studioName.style.position = "inherit";
	this.studioName.style.width = "188px";
	this.studioName.style.background = "transparent";
	this.studioName.style.border = "none";
	this.studioName.style.outline = "none";
	this.studioName.style.fontSize = "8pt";
	this.studioName.spellcheck = "false";

	this.studioName.style.left = "30px";
	this.studioName.style.top = "70px";
	this.studioName.hidden = 'true';

	this.div.appendChild(this.studioName);

	this.studioDescription = document.createElement("textarea");
	this.studioDescription.setAttribute("type", "text");
	this.studioDescription.setAttribute("class", "NavigationCanvas studioDescription");
	this.studioDescription.setAttribute("name", "studioDescription");
	this.studioDescription.setAttribute("id", "studioDescription");
	this.studioDescription.style.color = "White";
	this.studioDescription.style.position = "inherit";
	this.studioDescription.style.width = "250px";
	this.studioDescription.style.background = "transparent";
	this.studioDescription.style.border = "none";
	this.studioDescription.style.outline = "none";
	this.studioDescription.style.fontSize = "8pt";
	this.studioDescription.spellcheck = "false";

	this.studioDescription.style.left = "30px";
	this.studioDescription.style.top = "105px";
	this.studioDescription.hidden = 'true';

	this.div.appendChild(this.studioDescription);

	this.setupyourstudio_button = this.createClickAble('setupyourstudio_button', 80, 363, 144, 20, "game.navigation.setSelectedTab('createstudio');")
	this.setupyourstudio_cancel_button = this.createClickAble('setupyourstudio_cancel_button', 158, 375, 119, 17, "game.navigation.setSelectedTab('userstudios');")



	self.studioType = 1;
	self.studioLocation = 1;

	this.setSelectedStudioType = function (newType) {
		self.studioType = newType;
		console.log('selected studio type ' + self.studioType);
		
	}

	this.setStudioLocation = function (newLocation) {
		self.studioLocation = newLocation;
		console.log('selected studio location ' + self.studioLocation);

	}

	this.createStudio = function () {this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI NavigationCanvas");
		if (self.studioType == undefined) {
			self.studioType = 1;
		}

		if (self.studioLocation == undefined) {
			self.studioLocation = 1;
		}

		var studio = { "type": self.studioType, "location": self.studioLocation, "name": document.getElementsByName("studioName")[0].value, "description": document.getElementsByName("studioDescription")[0].value };

		socket.emit("CreateMyStudio", studio);

		console.log(studio);
	}

	this.enterStudio = function () {
		//socket.emit("RoomEnter", this.select[this.select.selectedIndex].value);
		socket.emit("RoomEnter", self.selectedRoomId);
		game.navigation.close();
		game.lobby.close();
		self.selectedRoom = null;
		self.selectedTab = 'publicview';

		$('.modify_studio').hide();
		$('.gointo_studio').hide();

		console.log('clear!');
	}

	this.modifyMyStudio = function () {

	}
	this.resetInterface = function () {

	}
	/*
			
	*/

	this.showActiveStudios = this.createClickAble('showActiveStudios', 17, 72, 131, 18, "game.navigation.setSelectedTab('userstudios_showActiveStudios');");
	this.showMyStudios = this.createClickAble('showMyStudios', 154, 72, 111, 18, "game.navigation.setSelectedTab('userstudios_showMyStudios');");
	this.searchBtn = this.createClickAble('searchBtn', 267, 72, 29, 18, "game.navigation.setSelectedTab('userstudios_searchBtn');");

	this.modify_studio = this.createClickAble('modify_studio', 97, 367, 118, 18, "game.navigation.setSelectedTab('userstudios_modifyMyStudio');");
	this.gointo_studio = this.createClickAble('gointo_studio', 218, 365, 68, 21, "game.navigation.enterStudio();");


	//left: 23px; width:67px; height: 23px; top: 353px;
	this.modify_ok = this.createClickAble('modify_ok', 23, 353, 67, 23, "game.navigation.setSelectedTab('userstudios_modifyMyStudio');");

	//position: inherit; left: 96px; width: 68px; height: 18px; top: 356px; display: inline-block;
	this.modify_cancel = this.createClickAble('modify_cancel', 96, 356, 68, 18, "game.navigation.setSelectedTab('userstudios');");

	//position: inherit; left: 167px; width: 129px; height: 18px; top: 356px; display: inline-block;
	this.modify_delete = this.createClickAble('modify_delete', 167, 356, 129, 18, "game.navigation.enterStudio();");

	/*
	this.ctx.drawImage(this.userstudios_showactive, 17, 73);
				this.ctx.drawImage(this.userstudios_showmy, 154, 73);
				this.ctx.drawImage(this.searchbar, 267, 73);
	*/

	this.setupstudio_type1 = this.createClickAble('setupstudio_type1', 30, 160, 56, 55, "game.navigation.setSelectedStudioType(1);");
	this.setupstudio_type2 = this.createClickAble('setupstudio_type2', 94, 160, 60, 55, "game.navigation.setSelectedStudioType(2);");
	this.setupstudio_type3 = this.createClickAble('setupstudio_type3', 163, 160, 55, 55, "game.navigation.setSelectedStudioType(3);");
	this.setupstudio_type4 = this.createClickAble('setupstudio_type4', 223, 160, 60, 55, "game.navigation.setSelectedStudioType(4);");
	this.setupstudio_type5 = this.createClickAble('setupstudio_type5', 31, 219, 63, 60, "game.navigation.setSelectedStudioType(5);");
	this.setupstudio_type6 = this.createClickAble('setupstudio_type6', 125, 219, 63, 60, "game.navigation.setSelectedStudioType(6);");
	this.setupstudio_type7 = this.createClickAble('setupstudio_type7', 220, 219, 63, 60, "game.navigation.setSelectedStudioType(7);");


	this.setupstudio_locMiami = this.createClickAble('setupstudio_locMiami', 30, 297, 100, 15, "game.navigation.setStudioLocation(1);");
	this.setupstudio_locMombasa = this.createClickAble('setupstudio_locMombasa', 30, 315, 100, 15, "game.navigation.setStudioLocation(2);");
	this.setupstudio_locNewYork = this.createClickAble('setupstudio_locNewYork', 30, 333, 100, 15, "game.navigation.setStudioLocation(3);");
	this.setupstudio_locLondon = this.createClickAble('setupstudio_locLondon', 30, 351, 100, 15, "game.navigation.setStudioLocation(4);");
	this.setupstudio_locSeattle = this.createClickAble('setupstudio_locSeattle', 140, 297, 100, 15, "game.navigation.setStudioLocation(5);");
	this.setupstudio_locSydney = this.createClickAble('setupstudio_locSydney', 140, 315, 100, 15, "game.navigation.setStudioLocation(6);");
	this.setupstudio_locTokyo = this.createClickAble('setupstudio_locTokyo', 140, 333, 100, 15, "game.navigation.setStudioLocation(7);");
	this.setupstudio_locRioDeJaneiro = this.createClickAble('setupstudio_locRioDeJaneiro', 140, 351, 100, 15, "game.navigation.setStudioLocation(8);");


	this.setupstudio_ok = this.createClickAble('setupstudio_ok', 80, 372, 69, 21, "game.navigation.createStudio();")

	

	this.showActiveStudioHolder = document.createElement("div");
	this.showActiveStudioHolder.setAttribute("class", "NavigationCanvas showActiveStudioHolder");
	this.showActiveStudioHolder.setAttribute("name", "showActiveStudioHolder");
	this.showActiveStudioHolder.style.position = "inherit";
	this.showActiveStudioHolder.style.left = "15px";
	this.showActiveStudioHolder.style.top = "95px";
	this.showActiveStudioHolder.style.height = "155px";
	this.showActiveStudioHolder.style.overflowY = "scroll";
	this.showActiveStudioHolder.hidden = true;
	this.div.appendChild(this.showActiveStudioHolder);

	this.showMyStudioHolder = document.createElement("div");
	this.showMyStudioHolder.setAttribute("class", "NavigationCanvas showMyStudioHolder");
	this.showMyStudioHolder.setAttribute("name", "showMyStudioHolder");
	this.showMyStudioHolder.style.position = "inherit";
	this.showMyStudioHolder.style.left = "15px";
	this.showMyStudioHolder.style.top = "95px";
	this.showMyStudioHolder.style.height = "155px";
	this.showMyStudioHolder.style.overflowY = "scroll";
	this.showMyStudioHolder.hidden = true;
	this.div.appendChild(this.showMyStudioHolder);

	

	//type == active|my
	this.clearUserStudioList = function (type) {

		var listType = '';
		var list = null;


		if (type == 'my') {
			listType = 'showMyStudioHolder';
			list = this.showMyStudioHolder;
		} else if (type == 'active') {
			listType = 'showActiveStudioHolder';
			list = this.showActiveStudioHolder;
		}

		existingRoomList = document.getElementsByClassName(listType)[0].getElementsByClassName('studioHolder');

		//without cleaning up event listeners, my "smart" toaster runs out of memory.
		for (var room = 0; room < existingRoomList.length; ) {
			var studioHolder = existingRoomList[room];
			var user_studiosEntry_htmlelementcollection = studioHolder.getElementsByTagName('user-studios');
			var user_studio = user_studiosEntry_htmlelementcollection[0];
			user_studio.removeEventListener('click', this.roomClickHandlers, false);
			user_studio.parentElement.remove(user_studio.parentElement.childNodes[0]);
			delete existingRoomList[room];
		}

	} 
	this.roomListClickHandlers = {};

	this.roomClickHandlers = function (event) {
		//console.log(this.innerHTML);
		console.log(this.getAttribute('roomid'));
		console.log(this.getAttribute('description'));


		if (this.getAttribute('roomid') != undefined) {
			self.selectedRoomId = this.getAttribute('roomid');
			self.selectedRoomName = this.getAttribute('roomname');
			self.selectedRoomPlayerCount = this.getAttribute('playercount');
			self.selectedRoomOwner = this.getAttribute('roomowner');
			self.selectedRoomDescription = this.getAttribute('description');

			//$('.setupyourstudio_button').hide();
			if (self.selectedTab == 'userstudios_showMyStudios') {
				$('.modify_studio').show();

			} else {
				$('.modify_studio').hide();

			}
			$('.gointo_studio').show();
			$('.setupyourstudio_button').hide();
		}
	}

	//type = active|my
	this.addToUserStudioList = function (type, roomList) {
		
		this.clearUserStudioList(type);

		var listType = '';
		var list = null;


		if (type == 'my') {
			listType = 'showMyStudioHolder';
			list = this.showMyStudioHolder;
		} else if (type == 'active') {
			listType = 'showActiveStudioHolder';
			list = this.showActiveStudioHolder;
		}

		

		console.log('y u fail me');
		console.log(list);

		for (var roomid in roomList) {
			var studioHolder = document.createElement("div");
			studioHolder.setAttribute("class", "NavigationCanvas studioHolder");
			//roomList[count].roomtype //roomList[count].location

			var entry = document.createElement("user-studios");
			entry.setAttribute("roomname", roomList[roomid].name);
			entry.setAttribute("roomid", roomList[roomid].id);
			entry.setAttribute("playercount", roomList[roomid].playercount);
			entry.setAttribute("description", roomList[roomid].description);
			entry.setAttribute("roomowner", roomList[roomid].ownername);
			entry.addEventListener('click', this.roomClickHandlers, false);

			studioHolder.appendChild(entry);
			list.appendChild(studioHolder);
		}
		
		if (document.getElementsByClassName(listType)[0].getElementsByClassName('studioHolder')[0] != undefined) {
			$('.' + listType).show();
		} else {
			$('.' + listType).hide();
		}

		
	}

	
}
