
function LoginCanvas() {
	var self = this;
	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');

	this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI LoginCanvas");
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "225px";
	this.div.style.top = "120px";

	this.loginStage = document.createElement("canvas");
	this.loginStage.setAttribute("name", "loginCanvas");
	this.loginStage.setAttribute("id", "loginCanvas");
	this.loginStage.setAttribute("class", "LobbyCanvas");
	this.loginStage.setAttribute("width", 318);
	this.loginStage.setAttribute("height", 148);
	this.loginStage.style.position = "absolute";
	this.loginStage.style.left = "0px";
	this.loginStage.style.top = "0px";
	this.ctx = this.loginStage.getContext('2d');


	
	console.log('showing Login canvas');


	this.performLogin = function () {
		var data = { username: self.txt_user.value, password: self.txt_pass.value };
		//game.lobby.showLobby();
		game.navigation.toggleDisplay();
		socket.emit("LoginRequest", data);
	}



	this.div.appendChild(this.loginStage);

	this.backgroundImage = new Image();
	this.backgroundImage.src = '../img/ui/cc.message.background.png';

	

	this.draw = function () {
		this.ctx.drawImage(self.backgroundImage, 0 , 0 ); // 74, 40
	}

	this.hideCanvas = function () {
		$('.LoginCanvas').hide();
	}
	this.showCanvas = function () {
		$('.LoginCanvas').show();
	}
	
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}

	this.txt_user = document.createElement("input");
	this.txt_user.setAttribute("type", "text");
	this.txt_user.setAttribute("class", "LoginCanvas");
	this.txt_user.setAttribute("name", "username");
	this.txt_user.setAttribute("id", "username");
	this.txt_user.setAttribute("value", "usernom");
	this.txt_user.style.position = "inherit";
	this.txt_user.style.width = "100px";
	this.txt_user.style.left = "110px";
	this.txt_user.style.top = "55px";
	this.div.appendChild(this.txt_user);

	this.txt_pass = document.createElement("input");
	this.txt_pass.setAttribute("type", "password");
	this.txt_pass.setAttribute("class", "LoginCanvas");
	this.txt_pass.setAttribute("name", "password");
	this.txt_pass.setAttribute("id", "password");
	this.txt_pass.setAttribute("value", "passnom");
	this.txt_pass.style.position = "inherit";
	this.txt_pass.style.width = "100px";
	this.txt_pass.style.left = "110px";
	this.txt_pass.style.top = "80px";
	this.div.appendChild(this.txt_pass);

	var btn_login = document.createElement("input");
	btn_login.setAttribute("type", "button");
	btn_login.setAttribute("value", "Login");
	btn_login.setAttribute("name", "btn_login");
	btn_login.setAttribute("id", "btn_login");
	btn_login.setAttribute("onclick", "game.login.performLogin()");
	btn_login.style.position = "inherit";
	btn_login.style.left = "140px";
	btn_login.style.top = "105px";
	this.div.appendChild(btn_login);
	this.mainDiv.appendChild(this.div);

} 