//main canvas size: width='850' height='600'
function CatalogCanvas() {
	self = this;

	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
	this.div.style.position = "absolute";
	this.div.style.left = "50px";
	this.div.style.top = "50px";
	this.div.setAttribute("name", "canvas_catalog");
	this.div.setAttribute("id", "canvas_catalog");
	this.div.setAttribute("width", 421+"px");
	this.div.setAttribute("draggable", "true");
	this.div.setAttribute("height", 442+"px");
	this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI CatalogCanvas");
	this.mainDiv.appendChild(this.div);

	this.catalogStage = document.createElement("canvas");
	this.catalogStage.setAttribute("name", "canvas_catalog");
	this.catalogStage.setAttribute("id", "canvas_catalog");
	this.catalogStage.setAttribute("class", "CatalogCanvas");
	this.catalogStage.setAttribute("width", 421);
	this.catalogStage.setAttribute("height", 442);
	this.catalogStage.style.position = "inherit";
	this.catalogStage.style.left = "0px";
	this.catalogStage.style.top = "0px";
	this.div.appendChild(this.catalogStage);

	this.ctx = this.catalogStage.getContext('2d');

	//catalog_bg.png
	this.catalog_bg = new Image();
	this.catalog_bg.src = '../img/ui/cc.interface.catalog.bg.png';
	//this.catalog_bg = new Image();



	this.page1_titlebg = new Image();

	this.pagetitlebg = new Image();
	this.pagetitlebg.src = '../img/ui/cc.catalogue.titlebg.png';


	this.page1_advert = new Image();
	

	this.page1_titlebg.src = '../img/ui/cc.catalogue.frontpage.title.png';
	this.page1_advert.src = '../img/ui/cc.catalogue.page1.onlinecatalogadvert.png';

	this.page1_divider_long = new Image();
	this.page1_divider_long.src = '../img/ui/cc.catalogue.divider.long.png';
	
	this.page1_advert_wallsandfloors = new Image();
	this.page1_advert_wallsandfloors.src = '../img/ui/cc.catalogue.advert.wallsandfloors.png';

	this.page1_advert_premiere = new Image();
	this.page1_advert_premiere.src = '../img/ui/cc.catalogue.advert.premiere.png';

	this.page1_advert_studiogear = new Image();
	this.page1_advert_studiogear.src = '../img/ui/cc.catalogue.advert.studiogear.png';

	this.close_x = new Image();
	this.button_b1_left = new Image();
	this.button_b1_middle = new Image();
	this.button_b1_right = new Image();
	this.close_x.src = '../img/ui/close-x.png';
	//cc.catalogue.
	/*
	this.button_b1_left.src = '../img/ui/button.b1.left.active.png';
	this.button_b1_middle.src = '../img/ui/button.b1.middle.active.png';
	this.button_b1_right.src = '../img/ui/button.b1.right.active.png';
	*/

	this.button_prev = new Image();
	this.button_next = new Image();

	/*
[ PAGE/CATEGORY ORDER ]
PAGE=[ #page: "", 	#catId: "12", 	#catName: "Special" ]
PAGE=[ #page: "1", 	#catId: "0", 	#catName: "Coke Studios Online Catalogue" ]
PAGE=[ #page: "2", 	#catId: "1", 	#catName: "Walls and Floor" ]
PAGE=[ #page: "3", 	#catId: "2", 	#catName: "Premiere" ]
PAGE=[ #page: "4", 	#catId: "3", 	#catName: "5001 Collection" ]
PAGE=[ #page: "5", 	#catId: "4", 	#catName: "Studio Essentials" ]
PAGE=[ #page: "6", 	#catId: "5", 	#catName: "Necessities1" ]
PAGE=[ #page: "7", 	#catId: "6", 	#catName: "Necessities2" ]
PAGE=[ #page: "8", 	#catId: "7", 	#catName: "Coke Collection" ]
PAGE=[ #page: "9", 	#catId: "8", 	#catName: "For Walls" ]
PAGE=[ #page: "10", 	#catId: "9", 	#catName: "Necessities3" ]
PAGE=[ #page: "11", 	#catId: "10", 	#catName: "Necessities4" ]
PAGE=[ #page: "12", 	#catId: "11", 	#catName: "Necessities5" ]
PAGE=[ #page: "13",	#catId: "13",	#catName: "Necessities6"]
PAGE=[ #page: "14",	#catId: "14",	#catName: "Necessities7"]
PAGE=[ #page: "15",	#catId: "15",	#catName: "Necessities8"]
*/

	this.pages = {
		0: { "title": "Special", "description": ""},
		1: { "title": "Coke Studios Online Catalogue", "description": ""},
		2: { "title": "Walls and Floor", "description": "You can customize the way your Studio looks with these wall and floor variations. Be sure to pick matching colors!" },
		3: {
			"title": "Premiere", "description": "Our exclusive  furniture provides  you with moments of slick  heavyweight   comfort. Enjoy it while the prices are low!",
			"items": {
				3: { "icon": new Image(), "buy": null },
				4: { "icon": new Image(), "buy": null },
				5: { "icon": new Image(), "buy": null },
				6: { "icon": new Image(), "buy": null },
				7: { "icon": new Image(), "buy": null },
				8: { "icon": new Image(), "buy": null },
				9: { "icon": new Image(), "buy": null },
				10: { "icon": new Image(), "buy": null }
			}
		},
		4: {
			"title": "5001 Collection", "description": "The 5001 product range is the closest you'll get to  comfort!",
			"items": {
				11: { "icon": new Image(), "buy": null },
				12: { "icon": new Image(), "buy": null },
				13: { "icon": new Image(), "buy": null },
				14: { "icon": new Image(), "buy": null },
				15: { "icon": new Image(), "buy": null },
				16: { "icon": new Image(), "buy": null },
				17: { "icon": new Image(), "buy": null },
				18: { "icon": new Image(), "buy": null }
				
			}
		},
		5: { "title": "Studio Essentials", "description": "" },
		6: { "title": "Necessities1", "description": "" },
		7: { "title": "Necessities2", "description": "" },
		8: { "title": "Coke Collection", "description": "" },
		9: { "title": "For Walls", "description": "" },
		10: { "title": "Necessities3", "description": "" },
		11: { "title": "Necessities4", "description": "" },
		12: { "title": "Necessities5", "description": "" }
	};




	this.image_location = '../img/ui/cc.catalogue.';
	//cc.catalogue.prev_button

	this.interfaces = {
		"buy": null,
		"prev_button": null,
		"next_button": null,
		"wallsandfloor_divider": null,
		"wallsandfloor_wallicon": null,
		"wallsandfloor_flooricon": null,
		"wallsandfloor_texture_description": null,
		"wallsandfloor_texturetitlebg": null,
		"wallsandfloor_texture_prev": null,
		"wallsandfloor_texture_next": null,
		"wallsandfloor_previewblank": null,
		"wallsandfloor_preview_default": null,
		"item_list_holder": null
		//
		//

	};

	for (let interface in this.interfaces) {
		this.interfaces[interface] = new Image();
		this.interfaces[interface].src = this.image_location + interface + '.png';
	}

	this.buyItem = function(itemId) {
		socket.emit('buyItem', { "item": itemId, "amount": 1 });
	}

	this.currentPage = 1;


	this.listItems = function () {
		if ("items" in this.pages[this.currentPage]) {
			var pageItems = this.pages[this.currentPage].items;
			var y = 92;


			for (item in pageItems) {
				var x = 68;
				var totalLineWidth = 0; //148.63461303710938 - max per line.
				var minusY = 0;

				pageItems[item].icon.src = '../img/furni/' + itemdb[item].icon + '.png';
				this.ctx.drawImage(pageItems[item].icon, 28, y);

				this.ctx.fillStyle = "#6B4832";
				this.ctx.font = 'bold 10pt Calibri';

				var continousLineWidth = this.ctx.measureText(itemdb[item]["name"] + " - " + itemdb[item]["cost"] + " dB").width;


				var listEntry = itemdb[item]["name"];
				listEntry = listEntry.split(" ");
				//console.log([listEntry.length, listEntry]);


				this.ctx.drawImage(this.interfaces["buy"], 227, y + 5);

				if (pageItems[item].buy == null) {
					pageItems[item].buy = this.createClickAble("buy_" + item, 227, y + 5, 41, 17, "game.catalog.buyItem(" + itemdb[item].id + ");");
				}

				if (listEntry.length > 3 || continousLineWidth > 100) {
					for (var i = 0; i < listEntry.length; i++) {
						var wordWidth = this.ctx.measureText(listEntry[i] + " ").width;

						if (totalLineWidth + wordWidth > (148 - 38)) { // go to next line if we're at risk of going over available line width 
							y += 13;
							x = 68;
							minusY = -13;
							totalLineWidth = 0;
						}

						this.ctx.fillText(listEntry[i] + " ", x, y + 10);
						x += wordWidth;
						totalLineWidth += wordWidth;
					}

					this.ctx.fillText(" - " + itemdb[item]["cost"] + " dB", x, y + 10);
					y += 36 + minusY;
				} else {
					console.log(continousLineWidth);
					this.ctx.fillText(itemdb[item]["name"] + " - " + itemdb[item]["cost"] + " dB", x, y + 10);
					y += 36
				}
			}
		}
	}

	this.draw = function () {
		this.ctx.drawImage(this.catalog_bg, 0, 0);
		this.ctx.drawImage(this.page1_divider_long, 27, 384);
		this.ctx.drawImage(this.interfaces["prev_button"], 25, 397);
		this.ctx.drawImage(this.interfaces["next_button"], 343, 397);
		this.ctx.font = '10pt Calibri';
		this.ctx.fillStyle = "#6B4832";
		this.ctx.fillText("Page " + this.currentPage + "/12", 176, 410);


		

		var description = this.pages[this.currentPage]["description"].split(" ");
		var descY = 110;
		this.ctx.font = '10pt Calibri';
		this.ctx.fillStyle = "#6B4832";


		for (var i = 1; i <= description.length; i += 3) {
			var line = '';
			for (var j = 0; j <= 2 && i + j <= description.length; j++) {
				line += description[i + j - 1] + ' ';
			}
			this.ctx.fillText(line, 283, descY);
			descY += 12;
		}

		


		//prepare
		this.ctx.font = 'bold 18pt Calibri';
		this.ctx.fillStyle = "#EEDBC6";

		switch (this.currentPage) {
			case 1:
				this.ctx.drawImage(this.page1_titlebg, 28, 50);
				titleParts = this.pages[this.currentPage]["title"].split(" ");

				this.ctx.fillText(titleParts[0] + " " + titleParts[1], 40, 73);
				this.ctx.fillText(titleParts[2] + " " + titleParts[3], 40, 98);
				this.ctx.drawImage(this.page1_advert, 45, 128);
				this.ctx.drawImage(this.page1_advert_wallsandfloors, 280, 115);
				this.ctx.drawImage(this.page1_advert_premiere, 280, 200);
				this.ctx.drawImage(this.page1_advert_studiogear, 280, 290);
				//this.ctx.drawImage(this.close_x, 388, 7);
				
				break;
			case 2:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);


				this.ctx.drawImage(this.interfaces["wallsandfloor_divider"], 25, 113);
				this.ctx.drawImage(this.interfaces["wallsandfloor_wallicon"], 25, 126);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_description"], 65, 131);

				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_prev"], 171, 127);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texturetitlebg"], 184, 126);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_next"], 258, 127);

				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_prev"], 171, 146);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texturetitlebg"], 184, 146);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_next"], 258, 146);

				//"wallsandfloor_texture_description": null,
				//"wallsandfloor_texturetitlebg": null

				
				

				this.ctx.drawImage(this.interfaces["wallsandfloor_divider"], 25, 254);
				this.ctx.drawImage(this.interfaces["wallsandfloor_flooricon"], 25, 268);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_description"], 65, 273);

				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_prev"], 171, 268);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texturetitlebg"], 184, 268);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_next"], 258, 268);


				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_prev"], 171, 288);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texturetitlebg"], 184, 288);
				this.ctx.drawImage(this.interfaces["wallsandfloor_texture_next"], 258, 288);

				this.ctx.font = 'bold 10pt Calibri';
				this.ctx.fillStyle = "#6B4832";
				this.ctx.fillText("Preview", 283, 261);
				//this.ctx.drawImage(this.interfaces["wallsandfloor_previewblank"], 283, 266);
				this.ctx.drawImage(this.interfaces["wallsandfloor_preview_default"], 283, 264);
				
				//wallsandfloor_previewblank

				//wallsandfloor_previewblank
				//wallsandfloor_preview_default
				break;
			case 3:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				this.listItems();
				break;
			case 4:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				this.listItems();
				break;
			case 5:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 6:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 7:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 8:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 9:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 10:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 11:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			case 12:
				this.ctx.drawImage(this.pagetitlebg, 26, 48);
				this.ctx.fillText(this.pages[this.currentPage]["title"], 40, 73);
				this.ctx.drawImage(this.interfaces["item_list_holder"], 68, 104);
				break;
			default:

		}


	}


	
	this.createClickAble = function(name, x, y, w, h, onClick, hoverable) {
		onClick = (typeof onClick === 'undefined') ? "console.log('" + name + "' button clicked in catalogue.)" : onClick;
		hoverable = (typeof hoverable === 'undefined') ? false : hoverable;

		var element = document.createElement("input");
		element.setAttribute("type", "button");
		element.setAttribute("value", "");
		element.setAttribute("id", name);
		element.setAttribute("name", name);
		element.setAttribute("class", "transparentStyling");
		element.setAttribute("onclick", onClick);
		element.style.position = "inherit";
		element.style.left = x + "px";
		element.style.width = w + "px";
		element.style.height = h + "px";
		element.style.top = y + "px";
		this.div.appendChild(element);

		if (hoverable) {
			element.onmouseover = function (event) {
				self.hoveringOn = name;
				console.log('hovering on catalogue ' + name + ' button ');

			}
			element.onmouseleave = function (event) {
				self.hoveringOn = '';
				console.log('stopped hovering on catalogue ' + name + ' button ');
			}
		}
		return element;
	};

	this.goToNextPage = function () {
		if (this.currentPage < 12) {
			this.currentPage++;
		}
	}
	this.goToPrevPage = function () {
		if (this.currentPage > 1) { 
			this.currentPage--;	
		}
		
	}
	this.nextButton = this.createClickAble("next_button", 343, 397, 48, 17, "game.catalog.goToNextPage();", true);
	this.prevButton = this.createClickAble("prev_button", 25, 397, 70, 17, "game.catalog.goToPrevPage();", true);


	//this.ctx.fillStyle = "rgba(237, 219, 197, 1.0)";
	//this.ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

	
	
	/*
	//TBDF
	var items = {
		"collection": "Premier"

	};

	var catalogItems = {"furniture": [
			{"id": 1, "name": "Red Sofa", "cost": 20, "description": "Feeling lazy?", "image": "../img/sofa_coke_small.png"},
			{"id": 2, "name": "Chair", "cost": 20, "description": "a chair for when you really need to sit.", "image": "../img/chair_coke_small.png"},
			{"id": 3, "name": "Orange Sofa", "cost": 20, "description": "A couch you'd probably find in garage sale.", "image": "../img/dorm_couch_small.png"}
		]
	};
	
	
	for(var furni=0; furni < catalogItems.furniture.length; furni++) {
		this.div.appendChild(createGUI("label", "red", "itemlabel_"+catalogItems.furniture[furni].id, "itemlabel_"+catalogItems.furniture[furni].id, catalogItems.furniture[furni].name, 50,  110 * furni, 150, 50));
		this.div.appendChild(createGUI("label", "red", "itemdesc_"+catalogItems.furniture[furni].id, "itemdesc_"+catalogItems.furniture[furni].id, catalogItems.furniture[furni].description, 50, 110 * furni + 15, 150, 50));
		this.div.appendChild(createGUI("img", "button", "item_"+catalogItems.furniture[furni].id, "item_"+catalogItems.furniture[furni].id, catalogItems.furniture[furni].image, 0, 110 * furni, 32, 32));
		this.div.appendChild(createGUI("input", "button", "buyitem_"+catalogItems.furniture[furni].id, "buyitem_"+catalogItems.furniture[furni].id, "Buy", 0, furni * 110 + 32, 50, 20));
	}
*/
	function createGUI(type, element, name, id, value, left, top, width, height) {
	
		var createdElement = document.createElement(type);
		
		if (type == "label") {
			createdElement.innerHTML += value;
			createdElement.id = id;
			createdElement.style.textAlign = "left";
			createdElement.name = name;
			createdElement.style.color = element;
		}
		else if (type == "img") {
			createdElement.src = value;
			createdElement.setAttribute("id", id);
			createdElement.setAttribute("name", name);
			createdElement.setAttribute("alt", element);
		} else {
			createdElement.setAttribute("type", element);
			createdElement.setAttribute("value", value);
			createdElement.setAttribute("name", name);
			createdElement.setAttribute("onclick", "socket.emit('debug', 'buy_"+id+"')");
		}
		
		createdElement.setAttribute("class", "CatalogCanvas Catalog");
		createdElement.style.position = "inherit";
		createdElement.style.left = left + "px";
		createdElement.style.top = top + "px";
		createdElement.style.height = height + "px";
		createdElement.style.width = width + "px";
		
		return createdElement;
	}
	
	this.show = function () {
		$('.CatalogCanvas').show();

	}
	
	this.hide = function() {
		$('.CatalogCanvas').hide();
	}
	
	this.toggleDisplay = function() {
		if(!$('.CatalogCanvas').is(":visible")) {
			$('.CatalogCanvas').show();
		} else {
			$('.CatalogCanvas').hide();
		}
	}




} 