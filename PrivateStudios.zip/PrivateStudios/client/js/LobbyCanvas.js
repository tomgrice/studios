function LobbyCanvas() {
	var self = this;
	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "0px";
	this.div.style.top = "0px";
	this.div.setAttribute('class', 'LobbyCanvas'); // and make sure myclass has some styles in css
	this.div.setAttribute('id', 'LobbyCanvasDiv'); // and make sure myclass has some styles in css
	

	this.lobbyStage = document.createElement("canvas");
	this.lobbyStage.setAttribute("name", "LobbyCanvas");
	this.lobbyStage.setAttribute("id", "LobbyCanvas");
	this.lobbyStage.setAttribute("width", 760);
	this.lobbyStage.setAttribute("height", 469);
	this.lobbyStage.style.position = "absolute";
	this.lobbyStage.style.left = "0px";
	this.lobbyStage.style.top = "0px";
	this.ctx = this.lobbyStage.getContext('2d');
	
	console.log('showing lobby canvas');

	this.div.appendChild(this.lobbyStage);

	this.backgroundImage = new Image();
	this.backgroundImage.src = '../img/ui/cc.entrance.bg3.png';

	this.draw = function () {
		this.ctx.drawImage(self.backgroundImage, 0 , 0 ); // 74, 40
	}

	this.hideCanvas = function () {
		$('.LobbyCanvas').hide();
	}
	this.close = function () {
		self.hideCanvas();
	}

	this.showCanvas = function () {
		$('.LobbyCanvas').show();
	}
	
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}
	
	this.mainDiv.appendChild(this.div);

} 