
//eventually this will be a Room class, and characters will be part of this eliminating need for seperate char handler.
function Map(startX, startY) {


	this.type = 0;
	this.hasLoaded = false;
	this.startX = 0;
	this.startY = 0;
	this.ownerName = "placeholder";
	this.studioName = "placeholder";
	this.startRow = 5;
	this.startCol = 3;
	this.furniture = [];

	// MOST RIGHT SQUARE WILL BE the last row, first column | why? because unlike a logical person, I decided to draw tiles backwards, indicating brain damage.
	this.plan = [ []	];
	this.tiles = [];
	this.clickableTiles = [];
	
	
	
	//reset tiles and plan.
	this.setPlan = function(newPlan) {
		this.hasUpdate = true;
		this.plan = [ []	];
		this.tiles = [ []	];
		this.furniture = [];
		
		this.plan = newPlan;//update new plan
		this.clickableTiles = []; // Required to reset clickable area.
		
		Types = {
			//floors
			"floor00": {	"clickable": false, "walkable": false,	"isFloor": true,	"isWall": false },
			"floor01": {	"clickable": true,	"walkable": true,	"isFloor": false,	"isWall": false },
			//walls
			"wall00": { 'clickable': false, "isWall": true, 'isFloor': false, "walkable": false},
			"wall01": { 'clickable': true, 'isFloor': false, "isWall": true, "walkable": false },
			//special
			"entrance01": { "clickable": true, "isFloor": true, "isWall": false, "walkable": false}
		}
		
		for(var i = 0,tileindex=0; i < this.plan.length; i++) { // Y ?
			for(var j = 0; j < this.plan[i].length; j++, tileindex++) {  // X ?
				this.tiles[tileindex] = new Tile(this.plan[i][j], j, i,this.startX, this.startY);
				if(this.plan[i][j] == 'tile01') {
					this.tiles[tileindex].clickable=true;
					this.clickableTiles[this.clickableTiles.length++] = this.tiles[tileindex];
				}
			}
		}
	}
	
	this.getFurniture = function() {
		return this.furniture;
	}
	
	this.addFurniture = function (furniID, dirz, row, column) {
		var furni = new Furniture(furniID, dirz, row, column);
		furni.updateDirectionIndex();
		this.furniture.push(furni);
	}


	this.removeFurniture = function (furniID, direction, column, row) {
		for (var i = 0; i < this.furniture.length; i++) {
			if (this.furniture[i].id == furniID && this.furniture[i].direction == direction && this.furniture[i].currentTileRow == row && this.furniture[i].currentTileCol == column) {
				//return this.furniture[i];
				this.furniture.splice(i, 1);
				console.log("removed requested furni");
			}
		}
	}

	//update this code for items that have more than one tile.
	this.getFurniAtCoords = function (col, row) {
		for (var i = 0; i < this.furniture.length; i++) {
			if (this.furniture[i].currentTileRow == row && this.furniture[i].currentTileCol == col) {
				return this.furniture[i];
			}
			
		}
		return null;
    }
	
	this.findClickedTile = function(x, y) {
		for(var j = 0; j < this.clickableTiles.length; j++) {  // X ?
			if(this.clickableTiles[j].contains(x,y)) {
				return this.clickableTiles[j].getColRow();
			}
		}
		return null; // didnt find the tile that was clicked.. odd .. error? but lets return false to error handle.
	}
	
	this.findHoveredTile = function(x, y) {
		for(var j = 0; j < this.clickableTiles.length; j++) {  // X ?
			if(this.clickableTiles[j].contains(x,y)) {
				return this.clickableTiles[j];
			}
		}
		return false; // didnt find the tile that was clicked.. odd .. error? but lets return false to error handle.
	}
	
	this.update = function() {
		if (!this.hasUpdate) { return; } // nothing to update
		
		//do update code
		
		if (this.furniture.length > 1) {
			this.furniture = this.furniture.sort(function(a,b) {
				  if (a.currentTileCol > b.currentTileCol) {
					 return -1;
					 }
				  if (a.currentTileCol < b.currentTileCol){
					return 1;
					}
				  return 0;
			});
			this.furniture = this.furniture.sort(function(a,b) {
				  if (a.currentTileRow > b.currentTileRow) {
					 return -1;
					 }
				  if (a.currentTileRow < b.currentTileRow){
					return 1;
					}
				  return 0;
			});
		}
		
		this.hasUpdate = false;
	}
	
	this.getMap = function() {
		return this.tiles;
	}


	this.overheadArrow = new Image();
	this.overheadArrow.src = '../img/cc.interface.highlight.large.png';

	this.item_actions = {
		"delete": { "img": new Image(), "btn": null, x: 550, y: 440, w: 62, h: 21 },
		"pickup": { "img": new Image(), "btn": null, x: 612, y: 440, w: 65, h: 21 },
		"rotate": { "img": new Image(), "btn": null, x: 677, y: 440, w: 63, h: 21 },
		"move": { "img": new Image(), "btn": null, x: 740, y: 440, w: 54, h: 21 }
	};

	for (let action in this.item_actions) { //item.action.delete.hover.png
		this.item_actions[action].img.src = '../img/ui/item.action.' + action + '.png';
		this.item_actions[action + ".hover"] = {
			"img": new Image(), "btn": null,
			x: this.item_actions[action].x, y: this.item_actions[action].y,
			w: this.item_actions[action].w, h: this.item_actions[action].h
		};
		this.item_actions[action + ".hover"].img.src = '../img/ui/item.action.' + action + '.hover.png';
	}


	var infostand = new Image();
	infostand.src = '../img/ui/cc.interface.infostand.png';

	this.selectedEntity = null;


	this.room_templates = {
		"1": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
		"4": { "img": null, "imgx": 15, "imgy": 15, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 8, "placementx": -34, "placementy": -2 },
		"3": { "img": null, "imgx": 150, "imgy": 30, "startrow": 5, "startcol": 3, "max_col": 6, "max_row": 6, "placementx": -48, "placementy": 13 },
		"2": { "img": null, "imgx": 10, "imgy": 2, "startrow": 9, "startcol": 3, "max_col": 10, "max_row": 10, "placementx": -44, "placementy": -86 }
		//"e": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
		//"f": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
		//"g": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 },
		//"h": { "img": null, "imgx": 30, "imgy": 2, "startrow": 5, "startcol": 3, "max_col": 10, "max_row": 6, "placementx": -25, "placementy": -14 }
	}

	for (var template in this.room_templates) {
		this.room_templates[template]["img"] = new Image();
		this.room_templates[template]["img"].src = '../img/model_' + template + '.png';
	}


	this.draw = function (context) {
		for (var i = 0, tileindex = 0; i < this.tiles.length; i++, tileindex++) { // Y ?
			this.tiles[tileindex].draw(context);
		}

		if (this.type > 0) {
			context.drawImage(this.room_templates[this.type]["img"], this.room_templates[this.type].imgx, this.room_templates[this.type].imgy);
		}

		context.font = '10pt Calibri';
		context.fillStyle = "#a4a4a4";
		context.fillText("Studio: " + this.name, 15, 440);
		context.fillText("Owner: " + this.ownerName, 15, 455);

		//info stand
		if (this.selectedEntity) { // clicked on player
			//this.stageCanvasContext.drawImage(btn_trade, 620, 440);
			//context.drawImage(btn_dance, 620, 440);

			context.drawImage(infostand, 650, 380);

			if (this.selectedEntity instanceof Furniture) {
				context.drawImage(this.selectedEntity.icon, 650 + 15, 380 - 10);

				if (this.hoveringOn == "rotate") {
					context.drawImage(this.item_actions["rotate.hover"].img, this.item_actions["rotate.hover"].x, this.item_actions["rotate.hover"].y);
				} else {
					context.drawImage(this.item_actions["rotate"].img, this.item_actions["rotate"].x, this.item_actions["rotate"].y);
				}

				if (this.hoveringOn == "move") {
					context.drawImage(this.item_actions["move.hover"].img, this.item_actions["move.hover"].x, this.item_actions["move.hover"].y);
				} else {
					context.drawImage(this.item_actions["move"].img, this.item_actions["move"].x, this.item_actions["move"].y);
				}

				if (this.hoveringOn == "pickup") {
					context.drawImage(this.item_actions["pickup.hover"].img, this.item_actions["pickup.hover"].x, this.item_actions["pickup.hover"].y);
				} else {
					context.drawImage(this.item_actions["pickup"].img, this.item_actions["pickup"].x, this.item_actions["pickup"].y);
				}

				if (this.hoveringOn == "delete") {
					context.drawImage(this.item_actions["delete.hover"].img, this.item_actions["delete.hover"].x, this.item_actions["delete.hover"].y);
				} else {
					context.drawImage(this.item_actions["delete"].img, this.item_actions["delete"].x, this.item_actions["delete"].y);
				}

				context.font = '10pt Calibri';
				context.fillStyle = "#FFFFFF";
				context.fillText(this.selectedEntity.name, 650 - 15, 380 + 42);
				context.fillStyle = "#FFFFFF";
				context.fillText(this.selectedEntity.description, 650 - 15 - 20, 380 + 42 + 10);
				context.drawImage(this.overheadArrow, this.tilex + 15, this.tiley - 50);
			}
			
		}

	}


	this.set = function (variable, value) {
		switch (variable) {

			case 'type':
				this.type = value;
				this.setX(this.room_templates[this.type].placementx);
				this.setY(this.room_templates[this.type].placementy);
				this.startCol = this.room_templates[this.type].startcol;
				this.startRow = this.room_templates[this.type].startrow;
				break;
			case 'startCol':
				this.startCol = value;

				break;
			case 'startRow':
				
				break;
			case 'description':
				this.description = value;
				break;
			case 'name':
				this.name = value;
				break;
			case 'ownername':
				this.ownerName = value;
				break;

			default:
				throw new Error("set() variable is not a valid option");
				break;
		}

	}
	this.setX = function (x) {
		this.startX = x;
	}
	
	this.setY = function (y) {
		this.startY = y;
	}

	this.getSpawnX = function() {
		return this.startCol;
	}
	
	this.getSpawnY = function() {
		return this.startRow;
	}
	
	this.getCoordOfTile = function(col,row) {
		//console.log((this.plan[row]));
		var mytile = {"x": this.tiles[row * (this.plan[row]).length + col].x, "y":this.tiles[row * (this.plan[row]).length + col].y};
		return mytile;
	}
	
	this.getCoordOfTile2 = function(col,row) {
		//console.log((this.plan[row]));
		var mytile = {"x": this.tiles[row * (this.plan[row]).length + col].x, "y":this.tiles[row * (this.plan[row]).length + col].y};
		return mytile;
	}


	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
	// set style
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "0px";
	this.div.style.top = "0px";
	// better to use CSS though - just set class
	this.div.setAttribute('class', 'itemActionButton'); // and make sure myclass has some styles in css
	this.div.setAttribute('id', 'RoomActionsDiv'); // and make sure myclass has some styles in css
	this.mainDiv.appendChild(this.div);


	this.hoveringOn = '';

	//delete, pickup, rotate, move
	this.btn_delete = document.createElement("input");
	this.btn_delete.setAttribute("type", "button");
	this.btn_delete.setAttribute("value", " ");
	this.btn_delete.setAttribute("name", "item_delete");
	this.btn_delete.setAttribute("class", "transparentStyling");
	this.btn_delete.setAttribute("id", "item_delete");
	this.btn_delete.setAttribute("onclick", "game.map.deleteItem();" );
	this.btn_delete.style.position = "inherit";
	this.btn_delete.style.left = this.item_actions["delete"].x + "px";
	this.btn_delete.style.width = this.item_actions["delete"].w + "px";
	this.btn_delete.style.height = this.item_actions["delete"].h + "px";
	this.btn_delete.style.top = this.item_actions["delete"].y + "px";
	this.div.appendChild(this.btn_delete);

	this.btn_delete.onmouseover = function (event) {
		this.hoveringOn = 'delete';
		console.log('map item  delete button highlight');

	}
	this.btn_delete.onmouseleave = function (event) {
		this.hoveringOn = '';
		console.log('map item delete button unhighlight');
	}

	this.deleteItem = function () {
		console.log('trying to delete: ' + this.selectedEntity.id + ' placed on ' + this.selectedEntity.currentTileCol + ',' + this.selectedEntity.currentTileRow);
		socket.emit('deleteFurni', { playerId: game.characterHandler.player.id, roomId: 0, itemid: this.selectedEntity.id, col: this.selectedEntity.currentTileCol, row: this.selectedEntity.currentTileRow, direction:this.selectedEntity.direction});
		//socket.emit('furniToRoom', { "itemid": this.userSelectedItem, "itemdir": 9, "col": this.hoveredTile.column, "row": this.hoveredTile.row });
	}

	this.btn_pickup = document.createElement("input");
	this.btn_pickup.setAttribute("type", "button");
	this.btn_pickup.setAttribute("value", " ");
	this.btn_pickup.setAttribute("name", "item_pickup");
	this.btn_pickup.setAttribute("class", "transparentStyling");
	this.btn_pickup.setAttribute("id", "item_pickup");
	this.btn_pickup.setAttribute("onclick", "game.map.pickupItem();");
	this.btn_pickup.style.position = "inherit";
	this.btn_pickup.style.left = this.item_actions["pickup"].x + "px";
	this.btn_pickup.style.width = this.item_actions["pickup"].w + "px";
	this.btn_pickup.style.height = this.item_actions["pickup"].h + "px";
	this.btn_pickup.style.top = this.item_actions["pickup"].y + "px";
	this.div.appendChild(this.btn_pickup);

	this.btn_pickup.onmouseover = function (event) {
		this.hoveringOn = 'pickup';
		console.log('map item pickup button highlight');

	}
	this.btn_pickup.onmouseleave = function (event) {
		this.hoveringOn = '';
		console.log('map item pickup button unhighlight');
	}
	this.pickupItem = function () {
		console.log('trying to pickup: ' + this.selectedEntity.id + ' placed on ' + this.selectedEntity.currentTileCol + ',' + this.selectedEntity.currentTileRow);
	}


	this.btn_rotate = document.createElement("input");
	this.btn_rotate.setAttribute("type", "button");
	this.btn_rotate.setAttribute("value", " ");
	this.btn_rotate.setAttribute("name", "item_rotate");
	this.btn_rotate.setAttribute("class", "transparentStyling");
	this.btn_rotate.setAttribute("id", "item_rotate");
	this.btn_rotate.setAttribute("onclick", "game.map.rotateItem();");
	this.btn_rotate.style.position = "inherit";
	this.btn_rotate.style.left = this.item_actions["rotate"].x + "px";
	this.btn_rotate.style.width = this.item_actions["rotate"].w + "px";
	this.btn_rotate.style.height = this.item_actions["rotate"].h + "px";
	this.btn_rotate.style.top = this.item_actions["rotate"].y + "px";
	this.div.appendChild(this.btn_rotate);

	this.btn_rotate.onmouseover = function (event) {
		this.hoveringOn = 'rotate';
		console.log('map item rotate button highlight');
	}

	this.btn_rotate.onmouseleave = function (event) {
		this.hoveringOn = '';
		console.log('map item rotate button unhighlight');
	}

	this.rotateItem = function () {
		console.log('trying to rotate: ' + this.selectedEntity.id + ' placed on ' + this.selectedEntity.currentTileCol + ',' + this.selectedEntity.currentTileRow);
		var oldDirection = this.selectedEntity.direction;
		this.selectedEntity.rotate();
		socket.emit('rotateFurni', { playerId: game.characterHandler.player.id, roomId: game.map.id, itemid: this.selectedEntity.id, col: this.selectedEntity.currentTileCol, row: this.selectedEntity.currentTileRow, old_direction: oldDirection, new_direction: this.selectedEntity.direction });
	}

	this.rotateFurniture = function (data) {

		console.log(data);
		//{ playerId: game.characterHandler.player.id, roomId: game.map.id, itemid: this.selectedEntity.id, col: this.selectedEntity.currentTileCol, row: this.selectedEntity.currentTileRow, old_direction: oldDirection, new_direction: this.selectedEntity.direction }
		//console.log([furniID, direction, row, column]);
		for (var i = 0; i < this.furniture.length; i++) {
			if (this.furniture[i].id == data.itemid && this.furniture[i].direction == data.old_direction && this.furniture[i].currentTileRow == data.row && this.furniture[i].currentTileCol == data.col) {
				this.furniture[i].rotate();
			}
		}
	}

	this.btn_move = document.createElement("input");
	this.btn_move.setAttribute("type", "button");
	this.btn_move.setAttribute("value", " ");
	this.btn_move.setAttribute("name", "item_move");
	this.btn_move.setAttribute("class", "transparentStyling");
	this.btn_move.setAttribute("id", "item_move");
	this.btn_move.setAttribute("onclick", "game.map.moveItem();");
	this.btn_move.style.position = "inherit";
	this.btn_move.style.left = this.item_actions["move"].x + "px";
	this.btn_move.style.width = this.item_actions["move"].w + "px";
	this.btn_move.style.height = this.item_actions["move"].h + "px";
	this.btn_move.style.top = this.item_actions["move"].y + "px";
	this.div.appendChild(this.btn_move);

	this.btn_move.onmouseover = function (event) {
		this.hoveringOn = 'move';
		console.log('map item move button highlight');

	}
	this.btn_move.onmouseleave = function (event) {
		this.hoveringOn = '';
		console.log('map item move button unhighlight');
	}
	this.moveItem = function () {
		console.log('trying to move: ' + this.selectedEntity.id + ' placed on ' + this.selectedEntity.currentTileCol + ',' + this.selectedEntity.currentTileRow);

		document.getElementById('mouse_follower_img').src = '../img/furni/' + game.itemdb[this.selectedEntity.id].icon + ".png";
		game.userSelectedItem = this.selectedEntity.id;
		this.removeFurniture(this.selectedEntity.id, this.selectedEntity.direction, this.selectedEntity.currentTileCol, this.selectedEntity.currentTileRow);

		console.log('trying to delete: ' + this.selectedEntity.id + ' placed on ' + this.selectedEntity.currentTileCol + ',' + this.selectedEntity.currentTileRow);
		//socket.emit('deleteFurni', { playerId: 0, roomId: 0, itemid: this.selectedEntity.id, col: this.selectedEntity.currentTileCol, row: this.selectedEntity.currentTileRow, direction: this.selectedEntity.direction });

	}
}