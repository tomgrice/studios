function MixerCanvas() {
	var self = this;
	this.mainDiv = document.getElementById('container');

	this.div = document.createElement('div');
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "0px";
	this.div.style.top = "0px";
	this.div.setAttribute('class', 'MixerCanvas'); // and make sure myclass has some styles in css
	this.div.setAttribute('id', 'MixerCanvasDiv'); // and make sure myclass has some styles in css
	

	this.mixerStage = document.createElement("canvas");
	this.mixerStage.setAttribute("name", "MixerCanvas");
	this.mixerStage.setAttribute("id", "MixerCanvas");
	this.mixerStage.setAttribute("width", 760);
	this.mixerStage.setAttribute("height", 469);
	this.mixerStage.style.position = "absolute";
	this.mixerStage.style.left = "0px";
	this.mixerStage.style.top = "0px";
	this.ctx = this.mixerStage.getContext('2d');
	
	console.log('showing mixerStage canvas');

	this.div.appendChild(this.mixerStage);

	//this.backgroundImage = new Image();
	//this.backgroundImage.src = '../img/ui/mixer.bg.instudio.png';

	this.mixer_parts = {
		"mixer.bg.instudio": { "img": new Image(), 'type': "bg"},
		"mixer.playbtn": { "img": new Image(), 'type': 'button'},
		"mixer.editbtn": { "img": new Image(), 'type': 'button'},
		"mixer.burnbtn": { "img": new Image(), 'type': 'button'},
		"mixer.closebtn": { "img": new Image(), 'type': 'button'},
	};

	for (let part in this.mixer_parts) {
		this.mixer_parts[part]["img"].src = '../img/ui/' + part + '.png';
		if (this.mixer_parts[part].type == "button") {
			this.mixer_parts[part + ".hover"] = {};
			this.mixer_parts[part + ".hover"]["img"] = new Image();
			this.mixer_parts[part + ".hover"]["img"].src = '../img/ui/' + part + ".hover" + '.png';

			if (part != "mixer.closebtn") {
				this.mixer_parts[part + ".clicked"] = {};
				this.mixer_parts[part + ".clicked"]["img"] = new Image();
				this.mixer_parts[part + ".clicked"]["img"].src = '../img/ui/' + part + ".clicked" + '.png';
            }
			
        }
    }

	//this.background_btn_shop = new Image();
	//this.background_btn_shop.src = '../img/shoppingCart.png';


	this.x = 100;
	this.y = 100;

	this.draw = function () {
		this.ctx.drawImage(this.mixer_parts['mixer.bg.instudio']['img'], this.x, this.y); // 74, 40
		
		if (self.hoveringOn == 'mixer_close') {
			this.ctx.drawImage(this.mixer_parts['mixer.closebtn.hover']['img'], this.x + 535, this.y + 15); // 74, 40
		} else {
			this.ctx.drawImage(this.mixer_parts['mixer.closebtn']['img'], this.x + 535, this.y + 15); // 74, 40
        }

	}


	this.btn_mixer_close = document.createElement("input");
	this.btn_mixer_close.setAttribute("type", "button");
	this.btn_mixer_close.setAttribute("value", " ");
	this.btn_mixer_close.setAttribute("name", "btn_mixer_close");
	this.btn_mixer_close.setAttribute("class", "transparentStyling");
	this.btn_mixer_close.setAttribute("id", "btn_mixer_close");
	this.btn_mixer_close.setAttribute("onclick", "game.mixer.close()");
	this.btn_mixer_close.style.position = "inherit";
	this.btn_mixer_close.style.left = this.x + 535 + "px";
	this.btn_mixer_close.style.top = this.y + 15 + "px";
	this.div.appendChild(this.btn_mixer_close);

	this.btn_mixer_close.onmouseover = function (event) {
		self.hoveringOn = 'mixer_close';
		console.log('mixer close button highlight');
	}
	this.btn_mixer_close.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('mixer close button unhighlight');
	}


	this.hideCanvas = function () {
		$('.MixerCanvas').hide();
	}
	this.close = function () {
		self.hideCanvas();
	}


	this.showCanvas = function () {
		$('.MixerCanvas').show();
	}
	
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}
	
	this.mainDiv.appendChild(this.div);

} 