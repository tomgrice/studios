function Stage(canvas) {

	var self = this;
	this.redrawRequired = true;
	this.canvas = canvas;
	this.width = canvas.width;
	this.height = canvas.height;
	this.ctx = canvas.getContext('2d');
	
	var stylePaddingLeft, stylePaddingTop, styleBorderLeft, styleBorderTop;
	if (document.defaultView && document.defaultView.getComputedStyle) {
		this.stylePaddingLeft = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingLeft'], 10)      || 0;
		this.stylePaddingTop  = parseInt(document.defaultView.getComputedStyle(canvas, null)['paddingTop'], 10)       || 0;
		this.styleBorderLeft  = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderLeftWidth'], 10)  || 0;
		this.styleBorderTop   = parseInt(document.defaultView.getComputedStyle(canvas, null)['borderTopWidth'], 10)   || 0;
	}

	var html = document.body.parentNode;
	this.htmlTop = html.offsetTop;
	this.htmlLeft = html.offsetLeft;

	this.objects = [];  // the collection of things to be drawn
	this.dragging = false; // Keep track of when we are dragging
	
	this.selection = null;
	this.dragoffx = 0; // See mousedown and mousemove events for explanation
	this.dragoffy = 0;
	
	this.selectionColor = '#FFFF00';
	this.selectionWidth = 0.5;  
	this.interval = 30;
	
	
	//fix text issue when double clicking to select
	canvas.addEventListener('selectstart', function(e) { e.preventDefault(); return false; }, false);
	
    /*canvas.onclick = function (event) {
		console.log('You clicked ' +  event);
    }*/


	canvas.addEventListener('dblclick', function (e) {
		game.mouseDblClicked(self.getMouse(e));

	}, true);

	canvas.addEventListener('mousedown', function(e) {
		game.mouseClicked(self.getMouse(e));		
	},true);

	canvas.addEventListener('mousemove', function(e) {
		game.mouseMoved(self.getMouse(e));
	}, true);
	

	
	this.getContext = function() {
		return self.ctx;
	}
	
	this.getMouse = function(e) {
		//console.log("trying to get mouse!");
		var element = this.canvas, offsetX = 0, offsetY = 0, mx, my;

		// Compute the total offset
		if (element.offsetParent !== undefined) {
			do {
				offsetX += element.offsetLeft;
				offsetY += element.offsetTop;
			} while ((element = element.offsetParent));
		}

		// Add padding and border style widths to offset Also add the <html> offsets in case there's a position:fixed bar
		offsetX += this.stylePaddingLeft + this.styleBorderLeft + this.htmlLeft;
		offsetY += this.stylePaddingTop + this.styleBorderTop + this.htmlTop;
		mx = e.pageX - offsetX;
		my = e.pageY - offsetY;

		return {x: mx, y: my};//  return a simple javascript object (a hash) with x and y defined
	}

	this.clear = function() {
		this.ctx.clearRect(0, 0, this.width, this.height);
	}
}
