//main canvas size: width='850' height='600'
function InventoryCanvas() {
	self = this;
	this.startingXoffset = 30;
	this.startingYoffset = 112;

	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
	this.mainDiv.appendChild(this.div);
// set style
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "50px";
	this.div.style.top = "50px";
	this.div.setAttribute("name", "div_inventory");
	this.div.setAttribute("id", "div_inventory");
	this.div.setAttribute("width", 238+"px");
	this.div.setAttribute("height", 336+"px");
	this.div.style.border = "5px solid thick";
	this.div.setAttribute("onmousemove", "game.inventory.myFunction(event)");
	this.div.setAttribute("onmouseup", "game.inventory.clicked(event)");



	this.background= new Image();
	this.background.src = '../img/ui/cc.interface.backpack.png';

	this.update = function() {
	
	}

	this.draw = function() {
		self.ctx.drawImage(self.background, 0, 0); // help

    }
	
	this.myFunction = function(e) {
		var x = e.clientX;
		var y = e.clientY;
		var coor = "Coordinates: (" + x + "," + y + ")";
		//console.log(coor);
	}

	this.createMouseFollower = function () {
		document.getElementById('mouse_follower_img').src = '../img/furni/' + itemdb[self.items[furni].id].icon + ".png";
	}

	//Create shadow click areas and test for them.
	this.clicked = function(e) {
		var x = e.clientX;
		var y = e.clientY;
		var coor = "clicked: (" + x + "," + y + ")";
		console.log(coor);
		document.getElementById('mouse_follower_img').src = '';
		for (var index = 0, row = 0, col = 0, furniIndex = Object.keys(game.inventory.items); index < furniIndex.length; null) {

			for (var col = 0; index <= furniIndex.length && col < 5; col++, index++ ) {
					
					//console.log("div: " + self.div.getBoundingClientRect().left + "," + self.div.getBoundingClientRect().top);
					mmx = self.startingXoffset + 37 * col;
					mmy = self.startingYoffset + 40 * row;  // ,
					if (self.contains(mmx,mmy,x,y)) {
						console.log("clicked: " + mmx + "," + mmy);
						console.log("dbg: " + index);

						/*
						if (self.furni[furniIndex[index]].src == "../img/shoppingCart.png") {
							self.furni[furniIndex[index]].src = "../img/furni/sofa_coke_small.png";
							game.userSelectedItem = false;
							document.getElementById('mouse_follower_img').src = '';
						} else {
							
						}*/

						if (this.furni[furniIndex[index]] == undefined) {
							game.userSelectedItem = false;
							return;
						}
						//if the slot is already empty, .src will throw an error.
						console.log(this.furni[furniIndex[index]]);
						self.furni[furniIndex[index]].src = "../img/emptyinventoryslot.png";
						document.getElementById('mouse_follower_img').src = '../img/furni/' + itemdb[self.items[furniIndex[index]].id].icon + ".png";
						//self.items[furniIndex[index]].id
						var selectedItemIdb = self.items[furniIndex[index]].id;

						console.log(['clicked inventory', index, furniIndex, furniIndex[index], self.items[furniIndex[index]], selectedItemIdb, itemdb[selectedItemIdb].dir[itemdb[selectedItemIdb].validDirections[0]], ]);
						game.userSelectedItem = { "id": self.items[furniIndex[index]].id, "direction": itemdb[selectedItemIdb].validDirections[0] }; //

						return;
					}
				}
				row++;
			}
	}
	


	this.contains = function(mx, my,x,y) {
			var context = self.ctx;
			//mx = mx;
			//my = my+this.div.style.top;
			context.fillStyle = "FF8040";
			context.beginPath();
			context.moveTo(mx,my);
			context.lineTo(mx+32,my	);
			
			context.lineTo(mx+32,my+32);
			context.lineTo(mx,my+32);
			context.lineTo(mx,my);			
			context.closePath();
			//context.stroke();
			return context.isPointInPath(x-self.div.getBoundingClientRect().left, y-self.div.getBoundingClientRect().top	);
	}

	this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI InventoryCanvas");


    

  
	this.inventoryStage = document.createElement("canvas");
	this.inventoryStage.setAttribute("name", "canvas_inventory");
	this.inventoryStage.setAttribute("id", "canvas_inventory");

	this.inventoryStage.setAttribute("class", "InventoryCanvas");
	this.inventoryStage.setAttribute("width", 238);
	this.inventoryStage.setAttribute("height", 336);
	this.inventoryStage.style.position = "inherit";
	this.inventoryStage.style.left = "0px";
	this.inventoryStage.style.top = "0px";
	
	
	this.ctx = this.inventoryStage.getContext('2d');
	//this.ctx.fillStyle = "rgba(0, 230, 255, .5)";

	//this.ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
	
	this.div.appendChild(this.inventoryStage);
	

	
	this.items;

	/*
	this.inventoryItems = {"furniture": [
			{"id": 1, "amount": 1},
		]
	};*/


	this.furni = [];
	//socket.emit('debug', "test");
	this.load = function() {
		//game.test();
		
	
		for (var index = 0, row = 0, col = 0, furniSlots = Object.keys(game.inventory.items); index < furniSlots.length;) {
			for (var col = 0; index <= furniSlots.length && col < 5; col++, index++) {

				console.log([index, furniSlots[index], this.items[furniSlots[index]], self.items[furniSlots[index]]]);
				//TODO: BUG FIX HERE
				if (self.items[furniSlots[index]] == undefined || itemdb[this.items[furniSlots[index]].id] == undefined) {
					console.log('found my issue');
					//this.items[furniSlots[index]]
					continue;
				}

				self.furni[furniSlots[index]] = createGUI("img", "button", "item_" + self.items[furniSlots[index]].id,
					"item_" + self.items[furniSlots[index]].id, '../img/furni/' + itemdb[self.items[furniSlots[index]].id].icon + ".png", self.startingXoffset + (32 + 5) * col, self.startingYoffset + (32 + 5	) * row, 32, 32);
				this.div.appendChild(self.furni[furniSlots[index]]);
			}
			row++;
		}
	}
	

	
	this.show = function () {
		$('.InventoryCanvas').show();
	}
	
	this.hide = function() {
		$('.InventoryCanvas').hide();
	}
	
	this.toggleDisplay = function() {
		if($('.InventoryCanvas').is(":visible")) {
			$('.InventoryCanvas').hide();
		} else {
			this.div.style.left = "50px";
			this.div.style.top = "50px";
			$('.InventoryCanvas').show();
		}
	}
	
	
	
	/* ** Internal Class Methods **  */
	function createGUI(type, element, name, id, value, left, top, width, height) {
	
		var createdElement = document.createElement(type);
		if (type == "label") {
			createdElement.innerHTML += value;
			createdElement.id = id;
			createdElement.style.textAlign = "left";
			createdElement.name = name;
			createdElement.style.color = element;
		}
		else if (type == "img") {
			createdElement.src = value;
			createdElement.setAttribute("id", id);
			createdElement.setAttribute("name", name);
			createdElement.setAttribute("alt", element);
		} else {
			createdElement.setAttribute("type", element);
			createdElement.setAttribute("value", value);
			createdElement.setAttribute("name", name);
			createdElement.setAttribute("onclick", "socket.emit('debug', 'buy_"+id+"')");
		}
		
		createdElement.setAttribute("class", "InventoryCanvas Inventory");
		createdElement.style.position = "inherit";
		createdElement.style.left = left + "px";
		createdElement.style.top = top + "px";
		createdElement.style.height = height + "px";
		createdElement.style.width = width + "px";
		
		return createdElement;
	}
} 