function CharacterSprite(character) {
	var self = this;
	this.character = character;
	this.currentFrame = 0;  
	this.currentTime = 0;
	this._direction = 5; // default direction, deprecated default value.

	this.sprites = new Image();
	this.timeSlot = [];
	this.load = function () {
		self.sprites.src = '../img/data.png';
		for (var h = 1; h < 10; h++) {//
			self.timeSlot[h] = [];
			for (var i = 0; i < 5; i++) {
				self.timeSlot[h][i] = 0.09;
			}
		}


	}
	
	var frameCounter = 0;
	var oddFrame = false;
	this.walking = false;

	this.update = function (direction, walking) {
		//console.log('character handler update called for me' + direction );

		self.currentTime += game.cycle.getCycleTime();
		self._direction = direction;
		self.walking = walking;

		if (self.currentTime > self.timeSlot[self._direction][self.currentFrame]) { // current time exceeds the permitted time for a the current frame.

			if (!this.walking) {
				self.currentFrame = 0;
			} else {
				if (frameCounter > 3) { // reset after max animation frame
					frameCounter = 0;
				}
				self.currentTime = 0;
				self.currentFrame = frameCounter++;
            }

		} else {
			// nothing to update. optimize it after.
		}

		//console.log('direction: ' + self._direction + 'time comparison: ' + self.currentTime + ' ' + self.timeSlot[self._direction][self.currentFrame] + ' current frame: ' + self.currentFrame);
	}

	// used for directions 1 (6), 4 (5), and 7 (4) 
	this.flipSpriteHorizontally = function (context, img, x, y, spriteX, spriteY, spriteW, spriteH) {
		// move to x + img's width adding img.width is necessary because we're flipping from
		//     the right side of the img so after flipping it's still  at [x,y]
		context.translate(x + spriteW, y);
		context.scale(-1, 1); // scaleX by -1; this "trick" flips horizontally

		// draw the img no need for x,y since we've already translated
		context.drawImage(img, spriteX, spriteY, spriteW, spriteH, 0, 0, spriteW, spriteH
		);

		// always clean up -- reset transformations to default
		context.setTransform(1, 0, 0, 1, 0, 0);
	}

	this.xoffset = -38;
	this.yoffset = -100;
	this.action = "";


	this.overheadArrow = new Image();
	this.overheadArrow.src = '../img/cc.interface.highlight.large.png';


	this.draw = function(context,x,y) {
		var drawnDirection = this._direction;

		var action = "std";
		var bodypart = "bd";
		var partstyle = "001"

		var dir = 3;
		switch (self._direction) {
			case 1:
			case 3:
				dir = 0;
				break;

			case 4:
			case 6:
				dir = 1;
				break;

			case 7:
			case 9:
				dir = 2;
				break;
			case 8:
				dir = 3;
				break;
			
			case 2:
				dir = 7;
				break;
			default:
				dir = 2;
				break;

		}

		for (var i in this.character.bodyparts) {

			if (!this.walking || this.currentFrame == 0) {
				this.action = "std";
				this.currentFrame = 0; // forcing a frame 0 in case we just stopped walking and frame was  > 0 | which would cause an error since there is no animation for standing && frame > 0
			} else {
				this.action = "wlk";
			}

			var action = this.action;
			var frame = this.currentFrame;

			// these body parts don't have additional frames. TODO: eyes have blink moments.
			if (i == "head" || i == "eye" || i == "face" || i == "chest"|| i =="hair") {
				action = "std";
				frame = "0";
			}

			if ((this._direction == 1 || this._direction == 2 || this._direction == 3) && (i == "eye" || i == "face")) { // facing backwards, eyes ,  face not needed.
				continue;
			}

			
			if (i == "lefthand" || i == "righthand" || i == "leftsleeve" || i == "rightsleeve" ) {
				if (this.walking && frame == "0") {
					frame = "1";
                }
				if (this.walking && frame == "2") {
					frame = "3";
				}

				if (this.action == "std") {
					frame = "0";
                }

			}
			

			var drawBody = "h_" + action + "_" + this.character.bodyparts[i][0] + "_" + this.character.bodyparts[i][1] + "_" + dir + "_" + frame + ".png";

			if (this._direction == 1 || this._direction == 4 || this._direction == 5 || this._direction == 7) {
				this.flipSpriteHorizontally(context, self.sprites, x + this.xoffset, y + this.yoffset, d[drawBody]["x"], d[drawBody]["y"], d[drawBody]["w"], d[drawBody]["h"], d[drawBody]["w"], d[drawBody]["h"]); // 74, 40

			} else {
				/*context.fillStyle = '#FF7700';
				context.globalCompositeOperation = 'multiply';
				context.fillRect(d[drawBody]["x"], d[drawBody]["y"], d[drawBody]["w"], d[drawBody]["h"]);
				context.globalAlpha = 0.5;
				context.globalCompositeOperation = 'destination-in';
				*/

				context.drawImage(self.sprites, d[drawBody]["x"], d[drawBody]["y"], d[drawBody]["w"], d[drawBody]["h"], x + this.xoffset, y + this.yoffset, d[drawBody]["w"], d[drawBody]["h"]); // 74, 40
			}

			//clothing color changes
			/*
			context.save();
			context.globalCompositeOperation = "color";
			context.fillStyle = "#BBFAAB";
			context.beginPath();
			context.fillRect(d[drawBody]["x"], d[drawBody]["y"], d[drawBody]["w"], d[drawBody]["h"]);
			context.closePath();
			context.fill();

			context.restore();
			*/
		}

		if (self.character.isSelected) {
			context.drawImage(this.overheadArrow, x - 15, y - 150);
        }

	}

	self.load();
}
