//this will need to transform into a generic client class.


var itemdb = {
	// 0 = door, 1-4 = default windows
	// mixer = 10
	"1": {
		"id": 1,
		"name": "Mixer",
		"description": "Make some music!", "space": 1,
		"cost": 0,
		"validDirections": [2, 6],
		"dir": {
			"2":
			{
				"1": { "img": "mixer_a_0_1_1_2_0", "xoffset": 2, "yoffset": -48 }
			},
			"6":
			{
				"1": { "img": "mixer_a_0_1_1_6_0", "xoffset": 2, "yoffset": -40 }
			}
		},
		"icon": "mixer_icon"
	},
	
	"3": {
		"id": 3, "name": "Premier Studio Chair",
		"description": "Premier comfort", "space": 1,
		"cost": 500,
		//
		"validDirections": [0, 2, 4, 6],
		"dir": {
			"0":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_0_0", "xoffset": -1, "yoffset": -35 }
			},
			"2":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_2_0", "xoffset": 0, "yoffset": -41 }
			},
			"4":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_4_0", "xoffset": 6, "yoffset": -41 }
			},
			"6":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_6_0", "xoffset": 5, "yoffset": -36 }
			}
		},
		"icon": "premier_studio_chair_icon"
	},
	"4": {
		"id": 4,
		"name": "Premier Stool",
		"description": "Premier comfort", "space": 1,
		"cost": 0,
		"validDirections": [2, 6],
		"dir": {},
		"icon": "premier_stool_icon"
	},
	"5": {
		"id": 5,
		"name": "Premier Sofa",
		"description": "Premier comfort for two", "space": 2,
		"cost": 0,
		"validDirections": [2, 6],
		"dir": {},
		"icon": "premier_sofa_icon"
	},
	"6": {
		"id": 6,
		"name": "Premier Coffee Table",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "premier_coffee_table_icon"
	},
	"7": {
		"id": 7,
		"name": "Premier Studio Table",
		"description": "", "space": 4,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "premier_studio_table_icon"
	},
	"8": {
		"id": 8,
		"name": "Premier Hi-Fi Stereo System",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "premier_hi-fi_stereo_system_icon"
	},
	"9": {
		"id": 9,
		"name": "Premier Studio Fridge",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "premier_studio_fridge_icon"
	},
	"10": {
		"id": 10,
		"name": "Premier Studio Lamp",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "premier_studio_lamp_icon"
	},
	"11": {
		"id": 11,
		"name": "5001 Series Chair",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_chair_icon"
	},
	"12": {
		"id": 12,
		"name": "5001 Series Stool",
		"description": "", "space": 2,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_stool_icon"
	},
	"13": {
		"id": 13,
		"name": "5001 Series Sofa",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_sofa_icon"
	},
	"14": {
		"id": 14,
		"name": "5001 Series Coffee Table",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_coffee_table_icon"
	},
	"15": {
		"id": 15,
		"name": "5001 Series Large Table",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_large_table_icon"
	},
	"16": {
		"id": 16,
		"name": "5001 Series Sound System",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_stereo_icon"
	},
	"17": {
		"id": 17,
		"name": "5001 Minibar",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_minibar_icon"
	},
	"18": {
		"id": 18,
		"name": "5001 Cube Light",
		"description": "", "space": 1,
		"cost": 0,
		"validDirections": [2],
		"dir": {},
		"icon": "5001_light_icon"
	}


	/*
				ITEM=[ #prodId: "11", #name: "5001 Chair", #type: "Chair", #action: "DEFAULT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Cushioned Chair", #roomDesc: "Have a seat", #imageBase: "5001_chair", #attributes: [:], #width: 1, #depth: 1, #height: 22, #itemsAllowedOnTop: false, #modifiable: true ]
ITEM=[ #prodId: "12", #name: "5001 Stool", #type: "Stool", #action: "DEFAULT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Stool", #roomDesc: "Take a load off", #imageBase: "5001_stool", #attributes: [:], #width: 1, #depth: 1, #height: 22, #itemsAllowedOnTop: false, #modifiable: true ]
ITEM=[ #prodId: "13", #name: "5001 Sofa", #type: "Sofa", #action: "DEFAULT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Sofa", #roomDesc: "Relax", #imageBase: "5001_sofa", #attributes: [:], #width: 2, #depth: 1, #height: 22, #itemsAllowedOnTop: false, #modifiable: true ]
ITEM=[ #prodId: "14", #name: "5001 Coffee Table", #type: "Table", #action: "DEFAULT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Coffee Table", #roomDesc: "5001 Coffee Table", #imageBase: "5001_ctable", #attributes: [:], #width: 1, #depth: 1, #height: 32, #itemsAllowedOnTop: true, #modifiable: true ]
ITEM=[ #prodId: "15", #name: "5001 Table", #type: "Table", #action: "DEFAULT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Large Table", #roomDesc: "5001 Table", #imageBase: "5001_table", #attributes: [:], #width: 2, #depth: 2, #height: 32, #itemsAllowedOnTop: false, #modifiable: true ]
ITEM=[ #prodId: "16", #name: "5001 Sound System", #type: "Default", #action: "STEREO", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Sound System", #roomDesc: "Play your mixes!", #imageBase: "5001_stereo", #attributes: [:], #width: 1, #depth: 1, #height: 62, #itemsAllowedOnTop: true, #modifiable: true ]
ITEM=[ #prodId: "17", #name: "5001 Minibar", #type: "Default", #action: "DRINK_DESPENSER", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Fridge", #roomDesc: "Thirsty?", #imageBase: "5001_minibar", #attributes: [:], #width: 1, #depth: 1, #height: 30, #itemsAllowedOnTop: true, #modifiable: true ]
ITEM=[ #prodId: "18", #name: "5001 Cube Light", #type: "Default", #action: "CUBE_LIGHT", #catName: "5001 Collection", #catId: "3", #catDesc: "5001 Series Cube Light", #roomDesc: "Decorative and functional", #imageBase: "5001_light", #attributes: [:], #width: 1, #depth: 1, #height: 62, #itemsAllowedOnTop: true, #modifiable: true ]
				*/
};



function Game() {
	var self = this;
	
	// THIS IS TEMPORARY! this info should be coming from the server when the client connects!
	// 6 7 0
	// 5 x 1
	// 4 3 2
	//dir_#_<space#>: image.png

	/*
	load images for all furniture  (this simulates "unpacking" a cache.., theres no packing/unpacking right now but this is the area i would do it)
	*/
	// BUG HERE: fix the dir[2] issue.


	//Load default images for page hover.


	/*
	for (var i = 1; i <= Object.keys(itemdb).length; i++) {

		if (itemdb[i] == undefined) {
			continue;
		}

		for(var dirs=0; dirs < 8; dirs++) {
			if (itemdb[i].dir[dirs] == undefined) { //if this direction is  not defined... for whatever reason (some furni might be restricted)
				continue;
			}
			for(var spc = 1;  spc <= itemdb[i].space; spc++ ) {
				var image = new Image();
				image.src = "../img/furni/" + itemdb[i].dir[dirs][spc].img + ".png";
				itemdb[i].dir[dirs][spc].image = image;
			}
		}
	}
	*/
	
	/*this.test = function() {
		console.log('test from game');
	}*/


	this.stageCanvasContext = document.getElementById('canvas').getContext('2d');
	
	this.cycle = new Cycle();
	
	//game settings and critical objects
	this.stage = new Stage(document.getElementById('canvas')); // Stuff to draw on
	this.fps = 30;
	
	this.map = new Map(0,0); // generate empty map to be replaced by server when a client connects to a room..
	this.characterHandler = new CharacterHandler(); //gives us access to the characters.

	this.chat = new Chat();

	this.lobby = new LobbyCanvas();
	this.controls = new ControlCanvas();
	this.navigation = new NavigationCanvas();
	this.navigation.close();
	this.alert = new AlertCanvas();
	this.catalog = new CatalogCanvas();
	this.inventory = new InventoryCanvas(); // my inventory
	this.login = new LoginCanvas();

	this.mixer = new MixerCanvas();


	this.catalog.toggleDisplay();
	this.mixer.close();
	this.inventory.toggleDisplay();
	$( ".draggableGUI" ).draggable();
	

	this._intervalId = setInterval(self.run, 1000/self.fps); // how fast/slow to run the game
	
	this.stageContext = this.stage.getContext();
	
	this.run = function() {
		self.update();
		self.draw();
		//self.stage.draw();
		self.cycle.complete();
	}
	
	this.roomFurniture = [];
		
	this.draw = function() {
		self.stage.clear();
		self.drawInterfaces();
		self.map.draw(this.stageContext);
		// MAP IS DRAWN! Time to draw characters and furni. but to do that we have to get the two and order them up:
		
		
		var chars = this.characterHandler.getCharacters();
		var furni = this.map.getFurniture();
		var objectsToDraw = furni.concat(chars);

		objectsToDraw = objectsToDraw.sort(function (a, b) {
			if (a.currentTileRow > b.currentTileRow) { // higher row (closer to user) will be drawn first 
				//console.log('furni row less than character row');
				return -1;
			}
			if (a.currentTileRow < b.currentTileRow) {
				//console.log('furni row greater than character row');
				return 1;
			}
			//console.log("the match was equal!1");
			return 0;
		});

		if (objectsToDraw.length > 1) {
			objectsToDraw = objectsToDraw.sort(function(a,b) {
				//console.log(" a is furni? " + (a instanceof Furniture) );				//console.log(" b is furni? " + (b instanceof Furniture) );
				if (a.currentTileCol < b.currentTileCol) {
					//console.log('furni col less than character col');
					return -1;
				}
				if (a.currentTileCol > b.currentTileCol){
				//	console.log('furni col greater than character col');
					if(a instanceof Furniture && a.spaces > 1) {
						if(a.currentTileCol >= b.currentTileCol-1) {
						
							return -1;
						}
					}
					return 1;
				}
				//console.log("the match was equal!2");
				return 0;
			});



		}
		
		if (self.hoveredTile != false ) {
			self.hoveredTile.drawOutline(this.stageContext);
		}		
		for (var key in objectsToDraw) {
			objectsToDraw[key].draw(this.stageContext);
		}

		/*working here

		"3": {
		"id": 3, "name": "Premier Studio Chair",
		"description": "Premier comfort", "space": 1,
		"cost": 500,
		//
		"validDirections": [0, 2, 4, 6],
		"dir": {
			"0":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_0_0", "xoffset": -1, "yoffset": -35 }
			},
			"2":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_2_0", "xoffset": 0, "yoffset": -41 }
			},
			"4":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_4_0", "xoffset": 6, "yoffset": -41 }
			},
			"6":
			{
				"1": { "img": "premier_studio_chair_a_0_1_1_6_0", "xoffset": 5, "yoffset": -36 }
			}
		},
		"icon": "premier_studio_chair_icon"
	}
		*/
		if (self.hoveredTile != false) {
			if (self.userSelectedItem != false) {
				for (var drawnSquare = 1; drawnSquare <= itemdb[self.userSelectedItem.id].space; drawnSquare++) {

					var defaultDirection = itemdb[self.userSelectedItem.id].validDirections[0];
					//console.log(defaultDirection);
					//console.log(itemdb[self.userSelectedItem.id].dir[defaultDirection][drawnSquare]);

					if (itemdb[self.userSelectedItem.id].dir[defaultDirection][drawnSquare] == undefined) {
						continue;
					}

					var defaultHoverImage = new Image();
					defaultHoverImage.src = '../img/furni/' + itemdb[self.userSelectedItem.id].dir[defaultDirection][drawnSquare].img + '.png';

					self.stageCanvasContext.drawImage(defaultHoverImage,
						self.hoveredTile.x + Number(itemdb[self.userSelectedItem.id].dir[defaultDirection][drawnSquare].xoffset),
						self.hoveredTile.y + Number(itemdb[self.userSelectedItem.id].dir[defaultDirection][drawnSquare].yoffset)
					);


				}
				document.getElementById('mouse_follower_img').src = '';
			}
		} else {
			
			//not hovering on a floor tile
			if (self.userSelectedItem != false) {
				document.getElementById('mouse_follower_img').src = '../img/furni/' + itemdb[self.userSelectedItem.id].icon + ".png"; 
				
				
			}
			
		}
		//self.characterHandler.draw(this.stageContext);
		
		//var fileFurniTile = self.map.findHoveredTile(mouse.x, mouse.y);
		
	}
	
	this.update = function () {

		if (self.map.hasLoaded) {
			self.map.update();//update map//first walls// then floor
			self.characterHandler.update(); // update all of our character's updates for this cycle.

		}
	}
	
	this.drawInterfaces = function() {
		self.navigation.draw();
		self.login.draw();
		self.alert.draw();
		self.lobby.draw();
		self.controls.draw();
		self.inventory.draw();
		self.catalog.draw();
		self.mixer.draw();
	}
	//handle events
	this.mouseClicked = function(mouse) {
		var clickedTile = self.map.findClickedTile(mouse.x, mouse.y);

		if (self.map.selectedEntity && self.map.selectedEntity.isSelected ) {
			self.map.selectedEntity.isSelected = false;//unselect previous item
		}

		console.log(clickedTile)
		console.log(self.map.selectedEntity)

		if (clickedTile != null) { // if clicked a tile
			if (self.userSelectedItem != false) { // if user has an item selected from inventory..
				//console.log(self.);
				var ob = { "id": self.userSelectedItem.id, "direction": self.userSelectedItem.direction, "col": self.hoveredTile.column, "row": self.hoveredTile.row };
				console.log(ob);
				socket.emit('furniToRoom',  ob);
				self.userSelectedItem = false;
				document.getElementById('mouse_follower_img').src = '';
			}

			var clickedFurni = self.map.getFurniAtCoords(clickedTile[0], clickedTile[1]);
			console.log(clickedTile[0] + ',' + clickedTile[1]);
			console.log(clickedFurni);

			if (clickedFurni != null) { // if there is already furni on the tile.. //code here to show options to rotate/move furni
				self.map.selectedEntity = clickedFurni;
				self.map.selectedEntity.isSelected = true;
			} else {

				var clickedPlayer = self.characterHandler.getPlayerAtCoords(clickedTile[0], clickedTile[1]);
				if (clickedPlayer != null) {
					self.map.selectedEntity = clickedPlayer;
					self.map.selectedEntity.isSelected = true;
				} else {
					self.map.selectedEntity = null;
                }

				
				self.characterHandler.hasUpdate = true;
				socket.emit('movePlayer', clickedTile[0], clickedTile[1]);
			}
		}
	}
	
	this.userSelectedItem = false;
	this.hoveredTile = false;

	//handle events
	this.mouseMoved = function(mouse) {
		self.hoveredTile = self.map.findHoveredTile(mouse.x, mouse.y);
	}

	this.mouseDblClicked = function (mouse) {
		//self.hoveredTile = self.map.findHoveredTile(mouse.x, mouse.y);
		console.log(["double clicked", self.map.selectedEntity]);
		if (self.map.selectedEntity instanceof Furniture && self.map.selectedEntity.id == 1) {
			self.mixer.showCanvas();
        }
	}
};