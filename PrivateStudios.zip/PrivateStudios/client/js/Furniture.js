function Furniture(furniID, direction, column, row) {
	/* 	//furniID, tilerow, tilecolumn, tilex, tiley
this x
this.y
this.z
this.direction
this.width
this.length
this.height
this.blocksTile
this.isSeat
this.canBeStackedOn
this.canBeStacked
this.interactions = [on, off,play, run]
this.animations
	 */
	var self = this;
	this.id = furniID;
	this.direction = direction;
	this.directionIndex = 0; // expected to be updated after creation.
	this.isSelected = false;
	this.currentTileRow = row;
	this.currentTileCol = column;
	this.tilex = game.map.getCoordOfTile(self.currentTileCol, self.currentTileRow).x;
	this.tiley = game.map.getCoordOfTile(self.currentTileCol, self.currentTileRow).y;
	this.cost = itemdb[this.id].cost;
	this.name = itemdb[self.id].name;
	this.description = itemdb[self.id].description;

	this.spaces = itemdb[self.id].space;
	this.validDirections = itemdb[self.id].validDirections;

	//this.direction = this.validDirections[this.directionIndex];
	
	this.img = {};

	for (var i = 0; i < this.validDirections.length; i++) {
		this.img[this.validDirections[i]] = {};

		for (var j = 1; j <= this.spaces; j++) {
			this.img[this.validDirections[i]][j] = { 'img': new Image() };
			this.img[this.validDirections[i]][j].img.src = '../img/furni/' + itemdb[self.id].dir[this.validDirections[i]][j]["img"] + '.png';
		}
    }

	this.icon = new Image();
	this.icon.src = '../img/furni/' + itemdb[self.id].icon + '.png';

	this.getDirectionIndex = function (direction) {

		for (var dirIdx = 0; dirIdx < this.validDirections.length; dirIdx++) {
			if (direction == this.validDirections[dirIdx]) {
				return dirIdx;
			}
		}
		return undefined;
	}

	this.updateDirectionIndex = function () {

		this.directionIndex = this.getDirectionIndex(this.direction); // just throw an error at this point...
	}

	this.rotate = function () {
		this.directionIndex++;

		if (this.directionIndex > itemdb[self.id].validDirections.length-1) {
			this.directionIndex = 0;
        }


		this.direction = this.validDirections[this.directionIndex];

	}

	this.draw = function (context) {
		for (var i = 0; i < this.validDirections.length; i++) {
			for (var j = this.spaces; j > 0; j--) {
				context.drawImage(this.img[this.validDirections[this.directionIndex]][j].img,
					this.tilex + Number(itemdb[this.id].dir[this.validDirections[this.directionIndex]][j].xoffset),
					this.tiley + Number(itemdb[this.id].dir[this.validDirections[this.directionIndex]][j].yoffset));
			}
		}
	}
}
