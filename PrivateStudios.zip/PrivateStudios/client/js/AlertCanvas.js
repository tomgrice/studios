//main canvas size: width='850' height='600'
function AlertCanvas() {
	self = this;
	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');

// set style
	this.div.setAttribute("class", "ui-widget-content ui-draggable ui-draggable-handle draggableGUI AlertCanvas");
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "0px";
	this.div.style.top = "0px";

	this.background_img = new Image();
	this.background_img.src = '../img/ui/cc.message.background.png';
	
	this.draw = function () {
		this.ctx.drawImage(this.background_img, 0,0);
	}
	

	this.alertStage = document.createElement("canvas");
	this.alertStage.setAttribute("name", "alertCanvas");
	this.alertStage.setAttribute("id", "alertCanvas");
	this.alertStage.setAttribute("class", "AlertCanvas");
	this.alertStage.setAttribute("width", 318);
	this.alertStage.setAttribute("height", 148);
	this.alertStage.style.position = "absolute";
	this.alertStage.style.left = "0px";
	this.alertStage.style.top = "0px";
	
	this.ctx = this.alertStage.getContext('2d');
	
	this.div.appendChild(this.alertStage);
		

	/*
	var btn_create = document.createElement("input");
	btn_create.setAttribute("value", "Create!");
	btn_create.setAttribute("type", "button");
	btn_create.setAttribute("class", "NavigationCanvas createRoomField");
	btn_create.setAttribute("name", "btn_create");
	btn_create.setAttribute("id", "btn_create");
	btn_create.setAttribute("onclick", "alert('This feature is currently unavailable.')");
	//btn_browseRoomList.setAttribute("onclick", "game.lobby.showBrowseRoomListOptions()");
	btn_create.style.position = "inherit";
	btn_create.style.left = 210 + 90 + 10 + "px";
	btn_create.style.top = "150px";
	this.div.appendChild(btn_create);
		*/
	this.toggleDisplay = function() {
		if(!$('.AlertCanvas').is(":visible")) {
			$('.AlertCanvas').show();
		} else {
			$('.AlertCanvas').hide();
		}
	}
	
	this.close = function() {
		$('.AlertCanvas').hide();
	}
	
	this.show = function() {
		$('.AlertCanvas').show();
	}

	/*
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}
	*/
	this.mainDiv.appendChild(this.div);
	self.close();
	
} 