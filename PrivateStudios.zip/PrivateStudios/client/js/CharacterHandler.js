function CharacterHandler() {
	var self = this;
	this.player = null;
	//this.myId (used in script.js)


	this.characters = new Array();
	this.hasUpdate = false;
	
	this.update = function() {

		
		
		for (var key in this.characters) {
			this.characters[key].update();
			
		}
		
		/*
			Sort characters in array by Column, then row.
		*/
		//sort by current column, then current row? 
		if (this.characters.length > 1) {
			this.characters = this.characters.sort(function(a,b) {
				  if (a.currentTileCol < b.currentTileCol) {
					 return -1;
					 }
				  if (a.currentTileCol > b.currentTileCol){
					return 1;
					}
				  return 0;
			});
			this.characters = this.characters.sort(function(a,b) {
				  if (a.currentTileRow < b.currentTileRow) {
					 return -1;
					 }
				  if (a.currentTileRow > b.currentTileRow){
					return 1;
					}
				  return 0;
			});
		}
	}
	
	this.draw = function(context) {
		for (var key in this.characters) {
			this.characters[key].draw(context);
		}
	}

	this.getPlayerAtCoords = function (col, row) {
		for (var i = 0; i < this.characters.length; i++) {
			if (this.characters[i].currentTileRow == row && this.characters[i].currentTileCol == col) {
				return this.characters[i];
			}

		}
		return null;
	}

	this.performLogin = function (data) {

		console.log();

		this.player = data;
		//        this.client.emit("loginAccepted", { id: this.id, status: this.status, money: this.money, username: this.username, displayname: this.displayname, bodyparts: this.bodyparts, inventory: this.inventory.items });

		//Character(x, y, id, displayname) 
		//var character = new Character(0, 0, data.id, data.displayname);

		//this.player;

		//this.characters.push(character);


	}

	this.addCharacter = function(x,y,player) {
		var character = new Character(x, y, player.id, player.displayname);

/*
		character.colTile = game.map.getSpawnX();
		character.rowTile = game.map.getSpawnY();

		/////////////
		character.destTileCol = game.map.getSpawnX();
		character.destTileRow = game.map.getSpawnY();

		character.nextTileCol = game.map.getSpawnX();
		character.nextTileRow = game.map.getSpawnY();

		character.currentTileCol = game.map.getSpawnX();
		character.currentTileRow = game.map.getSpawnY();*/

		//	var tileCoords = game.map.getCoordOfTile(self.nextTileCol, self.nextTileRow);
		//tileCoords.x += 37;
		//tileCoords.y += 18;


		//player.x = game.map.getCoordOfTile(player.currentTileCol, player.currentTileRow).x + 40;
		//player.y = game.map.getCoordOfTile(player.currentTileCol, player.currentTileRow).y + 23;



		//console.log("bdy parts");
		//console.log(character.bodyparts);

		for (var bodypart in character.bodyparts) {
			console.log(['dbgbodypart', bodypart, player.bodyparts[bodypart]]);
			character.bodyparts[bodypart][1] = player.bodyparts[bodypart];
		}

		//newChar.bodyparts
		character.graphics.load();

		this.characters.push(character);
		
		console.log('added new player!');
		
		game.stage.redrawRequired=true;
	}
	
	this.findIndexOfID = function(id){
		for(var i = 0; i < self.characters.length; i++) {
			if(self.characters[i].id == id) {
				return i;
			}
		}
		return false;
	}
	this.removeAllPlayers = function() {
		this.characters = new Array();
	}
	this.getCharacters = function() {
		/*var arraylist = [];
		for (var key in this.characters) {
			arraylist.push(self.characters[key]);
		}
		return arraylist;*/
		return self.characters;
		
	}
	
	this.remove = function(i) {
		game.stage.redrawRequired = true;
		console.log('removing player: ' + i);
	//	cosole.log('deleting ' + i + '  at ' + this.findIndexOfID(i));
		//delete this.characters(this.findIndexOfID(i));
		this.characters.splice(this.findIndexOfID(i), 1);
		return true;
		//return self.characters.splice(i,1);
	}
}