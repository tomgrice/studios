function Tile(p_type, p_column, p_row, mapStartX,mapStartY) {
	var self = this;
	
	this.type = p_type;
	this.column = p_column;
	this.row = p_row;

	this.clickable = false;
	this.draggable = false;
	this.occupied = false;
	
	var tileImage = new Image();
	tileImage.src = '../img/'+ self.type +'.png';
	
	
	this.w = 72; // tile width is 78 - 2
	this.h = 36;// tile height is 40 - 2
	this.startX = mapStartX;
	this.startY = mapStartY;
	
	this.hasUpdate = false;
	
	this.colCountAtRow = 11; // (map[i].length-1)
	
	
	this.x = (self.row-self.column) * self.w / 2  + ( self.colCountAtRow *(self.w/2)) + self.startX; 
	this.y = (self.row+self.column) * self.h / 2 + self.startY;//  + (startY + map[i].length*tileH);
	/*
	 screenX = (cellX * tile_width  / 2) + (cellY * tile_width  / 2)
            screenY = (cellY * tile_height / 2) - (cellX * tile_height / 2)
			*/
	this.draw = function(context) {
		context.drawImage(tileImage, self.x, self.y);
	}
	
	//38 x, 19 y = mid point
	this.contains = function(mx, my) {
		if (self.clickable /*&& self.pointInBounds(mx,my)*/) {
			var context = game.stage.getContext();
			
			context.moveTo(self.x,self.y+18);
			context.beginPath();
			context.lineTo(self.x+37,self.y);
			context.lineTo(self.x+38,self.y);
			
			context.lineTo(self.x+73,self.y+18);
			//context.lineTo(self.x+77,self.y+20);
			
			context.lineTo(self.x+36,self.y+36);
			//context.lineTo(self.x+38,self.y+39);
			
			context.lineTo(self.x,self.y+18);
			
			context.closePath();
			return context.isPointInPath(mx, my);
		}
		return false;
	}
	
	this.drawOutline = function(context) {
		//context.fillStyle = "FF8040";
		context.fillStyle = "#FFFFFF";
		context.beginPath();
		/*context.moveTo(self.x,self.y+20);
		context.lineTo(self.x+38,self.y);
		context.lineTo(self.x+39,self.y);
		context.lineTo(self.x+77,self.y+20);
		context.lineTo(self.x+77,self.y+20);
		context.lineTo(self.x+39,self.y+39);
		context.lineTo(self.x+39,self.y+39);
		context.lineTo(self.x,self.y+20);*/

		context.moveTo(self.x, self.y + 18);

		//context.lineTo(self.x + 37, self.y);
		context.lineTo(self.x + 37, self.y);
		context.lineTo(self.x + 36, self.y);

		context.lineTo(self.x + 73, self.y + 18);
		//	context.lineTo(self.x + 74, self.y + 18);
		//context.lineTo(self.x+77,self.y+20);

		context.lineTo(self.x + 36, self.y + 36);
		context.lineTo(self.x + 37, self.y + 36);
		//context.lineTo(self.x+38,self.y+39);

		context.lineTo(self.x, self.y + 18);
		
		context.closePath();
		context.stroke();
	}
	this.getColRow = function () {
		return [this.column, this.row];
	}

	this.getRowCol = function () {
		return [this.row, this.column];
	}
	
	// If the x,y are withing the rectangle of the image
	this.pointInBounds = function(mx, my) {
		return (self.x <= mx) && (self.x + self.w >= mx) && (self.y <= my) && (self.y + self.h >= my);
	}
	
}