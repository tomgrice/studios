var CANVAS_HEIGHT = 520; // fits full 600 pix
var CANVAS_WIDTH = 760; // fits 850 pix

var game;

var socket = io.connect('http://localhost:3000');

function sendChatMsg(fuck) {
	console.log(fuck);
}

var debugmsgs = document.getElementById('debugmsgs');

socket.on('debug', function(debugmsg) {
	console.log('debug packet recieved!');
	
	//document.getElementById('debugmsgs');
	var obj = debugmsg;
	
	var out = '';
    for (var i in obj) {
        out += i + ": " + obj[i] + "\n";
    }
	debugmsgs.innerHTML = debugmsgs.innerHTML + "\n" + out;
});	

socket.on('connect', function(){
	// call the server-side function 'adduser' and send one parameter (value of prompt)
	console.log('Connection to server established.');
	socket.emit('getMyID');
});

socket.on('loginAccepted', function(data) {
	console.log(data);
	console.log('login accept received');
	//console.log(data.inventory + " = inventory");
	//        this.client.emit("loginAccepted", { id: this.id, status: this.status, money: this.money, username: this.username, displayname: this.displayname, bodyparts: this.bodyparts, inventory: this.inventory.items });

	game.characterHandler.performLogin(data);


	game.inventory.items = data.inventory; // to be moved to player class in future.

	//game.characterHandler.myId = playerInfo.id;

	game.navigation.showCanvas();
	game.inventory.load();
	game.login.hideCanvas();
});

socket.on('debugmsg', function(){
	console.log('server sent a debug msg!');
});


socket.on('furniAdded', function(data){
	console.log("add furni " + JSON.stringify(data));
	//"itemid": data.itemid, "itemdir": data.itemdir, "col": data.col, "row": data.row
	game.map.addFurniture(data.itemid, data.direction, data.col, data.row);
});

socket.on('furniRotated', function (data) {
	game.map.rotateFurniture(data);
});

socket.on('furniRemoved', function (data) {
	game.map.removeFurniture(data.itemid, data.direction, data.col, data.row);
});

socket.on('msgSent', function(data) {

	game.chat.display(data.id, data.name, data.msg, data.x, data.y);
	console.log('Player ' + data.id + ' said ' + data.msg);
});

socket.on('playerLeftRoom', function(playerid){
	console.log('*****remove playerid *** ' + playerid);
	game.characterHandler.remove(playerid);
});

/*packet 5: new player being added */
socket.on('playerJoinRoom', function(player) {
	console.log("playerJoinRoom.");
	console.log('adding new player..' );
	console.log(player);

	//game.map = new map
	//game.map.isLoaded = true;


	///////////
	game.characterHandler.addCharacter(game.map.getSpawnX(), game.map.getSpawnY(), player); //row,col, player id
	//console.log(data);
});

socket.on('roomDetails', function (room) {

	//roomDetails ->  playerJoinRoom [new player] -> playerJoinRoom [tell new player about everyone thats already there] -> furniture


	console.log("room details recieved from server.");
	game.characterHandler.removeAllPlayers();
	game.map = new Map(0,0);

	game.map.hasLoaded = true;
	game.map.set('type', room.type);
	game.map.setPlan(room.map); //reset the map and set the new map plan as the current plan.
	game.map.set('ownername', room.ownername);
	game.map.set('name', room.name);

	/*mychar = game.characters[game.characterHandler.findIndexOfID(game.characterHandler.player.id)];

	mychar.destTileCol = game.map.getSpawnX();
	mychar.destTileRow = game.map.getSpawnY();

	mychar.nextTileRow = game.map.getSpawnY();
	mychar.nextTileCol = game.map.getSpawnY();

	mychar.currentTileRow = this.nextTileRow;
	mychar.currentTileCol = game.map.getSpawnY();

	mychar.x = game.map.getCoordOfTile(game.map.currentTileCol, game.map.currentTileRow).x + 40;// 
	mychar.y = game.map.getCoordOfTile(game.map.currentTileCol, game.map.currentTileRow).y+23;
	*/


});

//DEPRECATED with ROOM DETAILS
socket.on('roomMap', function(data) {
	console.log("roomMap called. recieved new room details");


	
	game.characterHandler.removeAllPlayers();
	game.map = new Map();


	//remove all players ? 
	var plan = data;
	game.map.setPlan(data); //reset the map and set the new map plan as the current plan.
	
	
	//myplan = data;
});

/* packet 6: moving player*/
socket.on('playerMoving', function(playerid, col, row){
	
	var playerIdx = game.characterHandler.findIndexOfID(playerid);
	
	console.log(playerid + " requested to move to ("+col+',' +row+")and i found them at index: " + playerIdx);
	
	if (playerIdx === false){ // reverse this logic to fix it :)
	} else {
		game.characterHandler.characters[playerIdx].move(parseInt(col),parseInt(row));
	}
});

/*packet 7: room response (list of rooms)*/
socket.on('activeRoomResponse', function (data) {

	console.log('aaab');
	console.log(data);
	console.log('aaab2');

	

	//game.lobby.removeOptions(game.navigation.select);
	//var roomList = data;
	//for (var roomId in roomList) {
	//	game.navigation.addOption(roomList[roomId].id, roomList[roomId].name, roomList[roomId].ownername, roomList[roomId].description, roomList[roomId].playercount);
	game.navigation.addToUserStudioList('active', data);

		//addOption(roomList[roomId].id, roomList[roomId].name, roomList[roomId].ownername, roomList[roomId].description, roomList[roomId].playercount);
	//}
});

/*packet 7: room response (list of rooms)*/
socket.on('roomResponse', function (data) {


	console.log(data);

	game.navigation.addToUserStudioList('my', data);
	/*
	game.lobby.removeOptions(game.navigation.select);
	var roomList = data;
	for(var roomId in roomList){
		game.navigation.addOption(roomList[roomId].id, roomList[roomId].name, roomList[roomId].ownername, roomList[roomId].description, roomList[roomId].playercount);
	}*/		
});


window.onload = function() { 
	game = new Game();
	game._intervalId = setInterval(game.run, 1000 / game.fps); //start loop
	// To stop the game, use the following: clearInterval(Game._intervalId);
};




console.log("test");


class ChatBubble extends HTMLElement {
	constructor() {
		super();
	}
	// Element functionality here.

	connectedCallback() {
		//console.log("Custom element added to page.");
	}

	disconnectedCallback() {
		//console.log("Custom element removed from page.");
	}

	adoptedCallback() {
		//console.log("Custom element moved to new page.");
	}

	attributeChangedCallback(name, oldValue, newValue) {
		//console.log(`Attribute ${name} has changed.`);
	}

}

customElements.define("chat-bubble", ChatBubble);




class UserStudios extends HTMLElement {
	constructor() {
		super();
	}
	// Element functionality written in here

	static observedAttributes = ["roomid", "description", "playercount", "roomname", "gobutton"];
	

	connectedCallback() {
		console.log("UserStudios element added to page.");
		let roomid = 0;
		
		if (this.hasAttribute("roomid")) {
			roomid = this.getAttribute("roomid");
		}

		let description = '';
		if (this.hasAttribute("description")) {
			description = this.getAttribute("description");
		}

		let playercount = 0;
		if (this.hasAttribute("playercount")) {
			playercount = this.getAttribute("playercount");
		}

		let roomname = '';
		if (this.hasAttribute("roomname")) {
			roomname = this.getAttribute("roomname");
		}

		let gobutton = 'Go!';
		if (this.hasAttribute("gobutton")) {
			gobutton = this.getAttribute("gobutton");
		}


		this.innerHTML = '<div class="playercount">' + playercount + '</div><div class="roomname">' + roomname + '</div><div class="go_button">' + gobutton + '</div>';

		this.style.color = "#6C472D";
		this.style.fontSize = '9px';
		this.style.fontFamily = "Calibri";
		this.style.cssFloat = 'left';
		this.style.overflow = 'hidden';
		this.style.width = "272px";
		this.style.position = "inherit";

		this.children[0].style.cssFloat = 'left';
		this.children[0].style.width = '5%';
		
		this.children[1].style.cssFloat = 'left';
		this.children[1].style.height = '1.05em';
		this.children[1].style.borderBottom = "1px dotted #6C472D";
		this.children[1].style.textDecoration = 'underline';
		this.children[1].style.width = '85%';
		this.children[1].style.textAlign = 'left';
		this.children[1].style.textIndent = '1px';

		this.children[2].style.cssFloat = 'right';
		this.children[2].style.width = '10%';
		this.children[2].style.height = '1.05em';
		this.children[2].style.borderBottom = "1px dotted #6C472D";
		this.children[2].style.textDecoration = 'underline';

	}

	disconnectedCallback() {
		//console.log("UserStudios element removed from page.");
	}

	adoptedCallback() {
		//console.log("UserStudios element moved to new page.");
	}

	attributeChangedCallback(name, oldValue, newValue) {
		//console.log(`UserStudios Attribute ${name} has changed.`);
	}

}

customElements.define("user-studios", UserStudios);