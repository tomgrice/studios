//main canvas size: width='850' height='600'
function ControlCanvas() {
	var self = this;
	this.mainDiv = document.getElementById('container');
	this.div = document.createElement('div');
// set style
	this.div.style.color = 'red';
	this.div.style.position = "absolute";
	this.div.style.left = "0px";
	this.div.style.top = "0px";
	// better to use CSS though - just set class
	this.div.setAttribute('class', 'myclass'); // and make sure myclass has some styles in css
	this.div.setAttribute('id', 'ControlCanvasDiv'); // and make sure myclass has some styles in css

	this.hoveringOn = '';

	this.lobbyStage = document.createElement("canvas");
	this.lobbyStage.setAttribute("name", "controlCanvas");
	this.lobbyStage.setAttribute("id", "controlCanvas");
	this.lobbyStage.setAttribute("width", CANVAS_WIDTH);
	this.lobbyStage.setAttribute("height", 50);
	this.lobbyStage.style.position = "absolute";
	this.lobbyStage.style.left = "0px";
	this.lobbyStage.style.top = "469px";
	//this.flag_redraw = true;
	
	this.context = this.lobbyStage.getContext('2d');
	//this.context.fillStyle = "rgba(255, 155, 255, 0.3)";
	//this.context.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
	
	//this.mainCanvas = document.getElementById('canvas'); //mainCanvas.style.display = 'none';

	this.div.appendChild(this.lobbyStage);
	
	this.background_img = new Image();
	this.background_img.src = '../img/ui/cc.interface.controls.bg.png';



	this.nav_actions_buttons = new Image();
	this.nav_actions_buttons.src = '../img/ui/bar-actions-buttons.png';

	this.chat_opt_speak = new Image();
	this.chat_opt_speak.src = '../img/ui/cc.chat.btn.speak.png';
	this.chat_txt_speak = new Image();
	this.chat_txt_speak.src = '../img/ui/cc.chat.txt.speak.png';

	this.chat_opt_shout = new Image();
	this.chat_opt_shout.src = '../img/ui/cc.chat.btn.shout.png';
	this.chat_txt_shout = new Image();
	this.chat_txt_shout.src = '../img/ui/cc.chat.txt.shout.png';


	//bar-actions-buttons.png
	this.draw = function () {
		//context.drawImage(self.im, 608 , 330 ); // 74, 40
		if (true) {
			this.context.drawImage(self.background_img, 0 , 0); // 74, 40
			this.context.drawImage(self.chat_opt_speak, 20, 10);
			this.context.drawImage(self.chat_txt_speak, 40, 13);
			this.context.drawImage(self.chat_txt_shout, 40, 28);
			//this.context.drawImage(self.chat_opt_shout, 0, 0);

			// draw buttons. | drawImage(img, sx, sy, swidth, sheight, x, y, width, height)

			this.context.drawImage(self.nav_actions_buttons, 0, 0, 21, 21, 465, 10, 20, 20); // navigation
			this.context.drawImage(self.nav_actions_buttons, 21, 0, 21, 21, 487, 10, 20, 20); // messenger
			this.context.drawImage(self.nav_actions_buttons, 41, 0, 21, 21, 508, 10, 20, 20); // decibels??
			this.context.drawImage(self.nav_actions_buttons, 62, 0, 21, 21, 529, 10, 20, 20); // backpack
			this.context.drawImage(self.nav_actions_buttons, 83, 0, 21, 21, 550, 10, 20, 20); // catalog
			this.context.drawImage(self.nav_actions_buttons, 104, 0, 21, 21, 571, 10, 20, 20); // music
			this.context.drawImage(self.nav_actions_buttons, 125, 0, 21, 21, 592, 10, 20, 20); // help

			//highlight the button the user is on.
			if (self.hoveringOn == 'nagivation') {
				self.context.drawImage(self.nav_actions_buttons, 0, 21, 21, 21, 465, 10, 20, 20); // navigation
			} else if (self.hoveringOn == 'messenger') {
				this.context.drawImage(self.nav_actions_buttons, 21, 21, 21, 21, 487, 10, 20, 20); // messenger
			} else if (self.hoveringOn == 'decibels') {
				self.context.drawImage(self.nav_actions_buttons, 41, 21, 21, 21, 508, 10, 20, 20); // decibels
			} else if (self.hoveringOn == 'backpack') {
				self.context.drawImage(self.nav_actions_buttons, 62, 21, 21, 21, 529, 10, 20, 20); // backpack
			} else if (self.hoveringOn == 'catalog') {
				self.context.drawImage(self.nav_actions_buttons, 83, 21, 21, 21, 550, 10, 20, 20); // catalog
			} else if (self.hoveringOn == 'music') {
				self.context.drawImage(self.nav_actions_buttons, 104, 21, 21, 21, 571, 10, 20, 20); // music
			} else if (self.hoveringOn == 'help') {
				self.context.drawImage(self.nav_actions_buttons, 125, 21, 21, 21, 592, 10, 20, 20); // help
			}
			
			


			//this.flag_redraw = false;
		}
	}
	

	this.chatbox = document.createElement("input");
	this.chatbox.setAttribute("type", "text");
	this.chatbox.setAttribute("class", "ControlCanvas");
	this.chatbox.setAttribute("name", "chatMsg");
	this.chatbox.setAttribute("id", "chatMsg");
	this.chatbox.style.position = "inherit";
	this.chatbox.style.width = "330px";
	this.chatbox.style.background = "transparent";
	this.chatbox.style.border = "none";
	this.chatbox.style.outline = "none";
	this.chatbox.style.fontSize = "8pt";
	this.chatbox.style.left = "96px";
	this.chatbox.style.top = "487px";
	
	this.chatbox.onkeyup = function(event) {
		console.log('key up event!');
		if(event.keyCode == 13){ // enter was pressed.
			/*socket.emit('debug');
			console.log('Enter was pressed!!');*/
			event.preventDefault();
			self.sendChatMessage();
		}
	}
	this.div.appendChild(this.chatbox);
	
	
	
	//sendChatMessage
	this.sendChatMessage = function() {

		var message = this.chatbox.value.trim();

		// If the message isn't blank, create it
		if (message != "" && !game.chat.isCommand(message)) {
			var characterIndex = game.characterHandler.findIndexOfID(game.characterHandler.player.id);
			//var characterIndex = game.characterHandler.findIndexOfID(1);
			var character = game.characterHandler.characters[characterIndex];
			//

			//game.character
			game.chat.create(game.characterHandler.player.displayname, message, null, character.currentTileCol, character.currentTileRow);
		}
		//socket.emit('clientChat', this.chatbox.value);
		this.chatbox.value = "";
	}
	
	
	/*this.sendchat.onkeyup = function() {
	console.log('key up event!');
	}*/
	/*
	this.select.ondblclick = function(){
	socket.emit("RoomEnter", this.options[this.selectedIndex].value);
	game.lobby.hideLobby();
	};*/

	
	/*$("#chatMsg").keyup(function(event){
	alert('test!');
	if(event.keyCode == 13){
	socket.emit('getMyID');
	console.log(this.val());
	}
	});*/
	
	
	this.btn_lobby = document.createElement("input");
	this.btn_lobby.setAttribute("type", "button");
	this.btn_lobby.setAttribute("value", " ");
	this.btn_lobby.setAttribute("name", "btn_lobby");
	this.btn_lobby.setAttribute("class", "transparentStyling");
	this.btn_lobby.setAttribute("id", "btn_lobby");
	this.btn_lobby.setAttribute("onclick", "game.navigation.toggleDisplay()");
	this.btn_lobby.style.position = "inherit";
	this.btn_lobby.style.left = "468px";
	this.btn_lobby.style.top = "479px";
	this.div.appendChild(this.btn_lobby);

	this.btn_lobby.onmouseover = function (event) {
		self.hoveringOn = 'nagivation';
		console.log('controls lobby button highlight');
	}
	this.btn_lobby.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('controls lobby button unhighlight');
	}



	this.btn_messenger = document.createElement("input");
	this.btn_messenger.setAttribute("type", "button");
	this.btn_messenger.setAttribute("value", " ");
	this.btn_messenger.setAttribute("name", "btn_messenger");
	this.btn_messenger.setAttribute("class", "transparentStyling");
	this.btn_messenger.setAttribute("id", "btn_messenger");
	this.btn_messenger.setAttribute("onclick", "game.alert.toggleDisplay()");
	this.btn_messenger.style.position = "inherit";
	this.btn_messenger.style.left = "488px";
	this.btn_messenger.style.top = "479px";
	this.div.appendChild(this.btn_messenger);

	this.btn_messenger.onmouseover = function (event) {
		self.hoveringOn = 'messenger';
		console.log('controls msg button highlight');
	}
	this.btn_messenger.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('controls msg button unhighlight');
	}

	this.btn_decibels = document.createElement("input");
	this.btn_decibels.setAttribute("type", "button");
	this.btn_decibels.setAttribute("value", " ");
	this.btn_decibels.setAttribute("name", "btn_decibels");
	this.btn_decibels.setAttribute("class", "transparentStyling");
	this.btn_decibels.setAttribute("id", "btn_decibels");
	this.btn_decibels.setAttribute("onclick", "game.decibels.toggleDisplay()");
	this.btn_decibels.style.position = "inherit";
	this.btn_decibels.style.left = "509px";
	this.btn_decibels.style.top = "479px";
	this.div.appendChild(this.btn_decibels);
	this.btn_decibels.onmouseover = function (event) {
		self.hoveringOn = 'decibels';
		console.log('controls decibels button highlight');
	}
	this.btn_decibels.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('controls decibels button unhighlight');
	}


	this.btn_inventory = document.createElement("input");
	this.btn_inventory.setAttribute("type", "button");
	this.btn_inventory.setAttribute("value", " ");
	this.btn_inventory.setAttribute("name", "btn_inventory");
	this.btn_inventory.setAttribute("class", "transparentStyling");
	this.btn_inventory.setAttribute("id", "btn_inventory");
	this.btn_inventory.setAttribute("onclick", "game.inventory.toggleDisplay()");
	this.btn_inventory.style.position = "inherit";
	this.btn_inventory.style.left = "529px";
	this.btn_inventory.style.top = "479px";
	this.div.appendChild(this.btn_inventory);
	this.btn_inventory.onmouseover = function (event) {
		self.hoveringOn = 'backpack';
		console.log('controls backpack button highlight');
	}
	this.btn_inventory.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('controls backpack button unhighlight');
	}

	this.btn_catalog = document.createElement("input");
	this.btn_catalog.setAttribute("type", "button");
	this.btn_catalog.setAttribute("value", " ");
	this.btn_catalog.setAttribute("name", "btn_catalog");
	this.btn_catalog.setAttribute("class", "transparentStyling");
	this.btn_catalog.setAttribute("id", "btn_catalog");
	this.btn_catalog.setAttribute("onclick", "game.catalog.toggleDisplay()");
	this.btn_catalog.style.position = "inherit";
	this.btn_catalog.style.left = "550px";
	this.btn_catalog.style.top = "479px";
	this.div.appendChild(this.btn_catalog);

	this.btn_catalog.onmouseover = function (event) {
		self.hoveringOn = 'catalog';
		console.log('controls catalog button highlight');
	}
	this.btn_catalog.onmouseleave = function (event) {
		self.hoveringOn = '';
		console.log('controls catalog button unhighlight');
	}
	
	
	this.showLobby = function () {
		socket.emit('RoomRequest');
		console.log('sent room request');
	}

	
	this.removeOptions = function(obj) {
		while(obj.options.length) {
			obj.remove(0);
		}
	}
	
	this.mainDiv.appendChild(this.div);

} 