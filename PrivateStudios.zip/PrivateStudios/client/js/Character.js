
function Character(x, y, id, displayname) {

	var self = this;
	var charWidth = 40; //what is the character's total width (calculate on creation).. for now we'll just use whatever.
	var charHeight = 74; //what is the character's total height (calculate on creation).. for now we'll just use whatever.

	
	this.money = 0;
	this.inventory = 0;
	this.id = typeof id !== 'undefined' ? id : -1;
	this.displayname = displayname;
	this.hasUpdate = false;

	this.isSelected = false;
	this.isDancing = false;
	this.isDrinking = false;

	this.bodyparts = {
		"body": ["bd", "001"],
		"head": ["hd", "001"],
		"hair": ["hr", "001"],
		"face": ["fc", "001"],
		"eye": ["ey", "001"],
		"chest": ["ch", "001"],
		"legs": [ "lg", "001"],
		"lefthand": [ "lh", "001"],
		"leftsleeve": [ "ls", "001"],
		"righthand": [ "rh", "001"],
		"rightsleeve": [ "rs", "001"],
		"shoes": ["sh", "001"]
	};

	this.walking = false;	
	var direction = 5;
	
	this.destTileCol = typeof x !== 'undefined' ? x : 0;
	this.destTileRow = typeof y !== 'undefined' ? y : 0;
	
	this.nextTileRow = this.destTileRow;
	this.nextTileCol = this.destTileCol;
	
	this.currentTileRow = this.nextTileRow;
	this.currentTileCol = this.destTileCol;
	
	this.x = game.map.getCoordOfTile(self.currentTileCol, self.currentTileRow).x+40;
	this.y = game.map.getCoordOfTile(self.currentTileCol, self.currentTileRow).y+23;
	
	


	this.parts = [];

	
	this.move = function (x,y) {
		this.destTileRow = y;
		this.destTileCol = x;
	}
	
	this.contains = function(mx, my) {
		return  (this.x <= mx) && (this.x + this.w >= mx) &&    (this.y <= my) && (this.y + this.h >= my);
	}	
	
	this.update = function () {
		
		self.calculateDestination();
		self.walk();
		self.graphics.update(direction,self.walking);
	}

	this.graphics = new CharacterSprite(self);

	
	this.calculateDestination = function() {
		if(self.currentTileRow == self.nextTileRow && self.currentTileCol == self.nextTileCol) {//if current tile == next tile, find next tile to get to
			
			if(self.currentTileRow == self.destTileRow && self.currentTileCol == self.destTileCol) {
				this.walking = false;//we got no where to go, so lets just match this condition so that we dont have to check the next 8 conditions lol
				
			}
			else if (self.currentTileRow < self.destTileRow && self.currentTileCol < self.destTileCol) {
				self.nextTileRow++;
				self.nextTileCol++;
				direction = 8;
				this.walking = true;
			}
			else if(self.currentTileRow > self.destTileRow && self.currentTileCol < self.destTileCol) {
				self.nextTileRow--;
				self.nextTileCol++;
				direction = 4;
				this.walking = true;
			}
			else if (self.currentTileRow < self.destTileRow && self.currentTileCol > self.destTileCol) {
				self.nextTileRow++;
				self.nextTileCol--;
				direction = 6;
				this.walking = true;
			}
			else if (self.currentTileRow > self.destTileRow && self.currentTileCol > self.destTileCol) {
				self.nextTileRow--;
				self.nextTileCol--;
				direction = 2;
				this.walking = true;
			}
			else if (self.currentTileRow < self.destTileRow) {
				self.nextTileRow++;
				direction = 9;
				this.walking = true;
			}
			else if (self.currentTileRow > self.destTileRow) {
				self.nextTileRow--;
				direction = 1;
				this.walking = true;
			}
			else if (self.currentTileCol < self.destTileCol) {
				self.nextTileCol++;
				direction = 7;
				this.walking = true;
			}
			else if (self.currentTileCol > self.destTileCol) {
				self.nextTileCol--;
				direction = 3;
				this.walking = true;
			}
		}
	}
	
	this.walk = function() {
		var tileCoords = game.map.getCoordOfTile(self.nextTileCol, self.nextTileRow);
		tileCoords.x +=37;
		tileCoords.y +=18;
		var yMoveDistance = 1, xMoveDistance = 2;
		
		//console.log([this.x, this.y, tileCoords.x, tileCoords.y]);
		

		if(this.x == tileCoords.x && this.y == tileCoords.y){
			self.currentTileRow = self.nextTileRow;
			self.currentTileCol = self.nextTileCol;
		}
		
		if (Math.abs(tileCoords.x - this.x) % xMoveDistance != 0) {
			xMoveDistance = 1;
		}
		
		//correct y movement if we end up in a weird place
		if (Math.abs(tileCoords.y - this.y) % yMoveDistance != 0) {
			yMoveDistance = 1;
		}
		
		if (tileCoords.x > this.x) {
			this.x += xMoveDistance;
			//--->
		}
		else if (tileCoords.x < this.x) {
			this.x -= xMoveDistance;
			// <---
		}
		
		if (tileCoords.y > this.y) {
			this.y += yMoveDistance;
			//move down
		}
		else if (tileCoords.y < this.y) {
			this.y -= yMoveDistance;
			//move up
		}
	}



	var btn_trade = new Image();
	btn_trade.src = '../img/ui/cc.action.trade.hover.png';

	var btn_dance = new Image();
	btn_dance.src = '../img/ui/cc.action.dance.hover.png';

	//var btn_cancel = new Image();
	//btn_cancel.src = '../img/ui/cc.action.dance.hover.png';

	var infostand = new Image();
	infostand.src = '../img/ui/cc.interface.infostand.png';


	this.draw = function (context) {
		self.graphics.draw(context, self.x, self.y);

		// display username above head.
		context.font = '11pt Calibri';
		context.fillStyle = 'white';
		context.strokeText(this.displayname, self.x - 20, self.y - 120);


		//info stand
		if (self.isSelected) { // clicked on player
			//self.stageCanvasContext.drawImage(btn_trade, 620, 440);
			context.drawImage(btn_dance, 620, 440);

			context.drawImage(infostand, 650, 380);
			//self.stageCanvasContext.drawImage(overheadArrow, self.selectedEntity.x - 15, self.overheadDrawOn.y - 150);
		} 

	}

}