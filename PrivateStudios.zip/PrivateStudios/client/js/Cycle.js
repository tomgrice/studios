/*
	Cycle	 Its basically a timer class..
*/

function Cycle() {
	var self = this;
	//WARNING: DATE.NOW DOES NOT EXIST IN OLDER BROWSERS.. SO USE
	if (!Date.now) {  
		Date.now = function() {  
			return +(new Date);  
		};  
	}
    
	var currentCycleTime = Date.now();
	var lastCycleTime = currentCycleTime;
	var difference = 0;
	
	
	
    this.getCycleTime = function() {
        return difference / 1000; // seconds.. how long 1 game cycle takes
    }
	
	 /*
		Function:		complete()
		
		Description:	completes a cycle by updating time values and by 
						calculating the delta time between start and finish of a game loop
	 */
	 
    this.complete = function() {
        currentCycleTime = Date.now();
		difference = currentCycleTime - lastCycleTime;
		lastCycleTime = currentCycleTime;
    }
	
}